module novo_projeto {
}