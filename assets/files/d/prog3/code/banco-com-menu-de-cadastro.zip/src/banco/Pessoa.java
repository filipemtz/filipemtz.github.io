package banco;

import java.util.Scanner;

public class Pessoa {
	String nome;
	String cpf;
	String telefone;
	int idade;
	
	Pessoa() {
		Scanner s = new Scanner(System.in);

		System.out.print("Nome: ");
		nome = s.nextLine();
		
		System.out.print("Idade: ");
		idade = s.nextInt();
		
		System.out.print("CPF: ");
		cpf = s.next();
		
		System.out.print("Telefone: ");
		s.nextLine();  
		telefone = s.nextLine();
	}
	
	Pessoa(String n, String c, String t, 
			int i) {
		nome = n;
		cpf = c;
		telefone = t;
		idade = i;
	}
	
	public String toString() {
		// Pessoa(Jose, cpf=123, telefone=123, idade=25)
		return "Pessoa(" + nome + 
				", cpf=" + cpf + 
				", telefone=" + telefone +
				", idade=" + idade + ")";
	}
}
