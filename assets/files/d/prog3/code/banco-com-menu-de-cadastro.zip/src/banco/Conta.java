package banco;

import java.util.Scanner;

public class Conta {
	String numero;
	double saldo;
	double limite; 
	Pessoa titular;
	
	double disponivel() {
		return saldo + limite;
	}
	
	boolean saque(double valor) {
		if (valor < disponivel()) {
			saldo -= valor;
			return true;
		}
		else {
			System.out.println(
					"Saldo insuficiente.");
			return false;
		}
	}
	
	Conta() {
		Scanner s = new Scanner(System.in);

		System.out.print("Numero: ");
		numero = s.nextLine();
		
		System.out.print("Saldo: ");
		saldo = s.nextDouble();
		
		System.out.print("Limite: ");
		limite = s.nextDouble();
		
		titular = new Pessoa();
	}
	
	Conta(String numero, Pessoa titular) {
		this(numero, titular, 0.0, 100.0);
	}
	
	Conta(String numero, Pessoa titular, 
			double saldo, double limite) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
		this.limite = limite;
	}
	
	public String toString() {
		return "Conta(" + numero + 
				", saldo=" + saldo + 
				", limite=" + limite +
				", titular=" + titular +
				")";
	}
	
	
}
