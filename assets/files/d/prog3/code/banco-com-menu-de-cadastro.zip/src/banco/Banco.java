package banco;

import java.util.ArrayList;
import java.util.Scanner;

public class Banco {
	ArrayList<Conta> contas;
	
	Banco() {
		contas = new ArrayList<>();
	}
	
	void cadastrarConta() {
		Conta c = new Conta();
		contas.add(c);
	}
	
	void listarContas() {
		// Uma forma de implementar o loop:
		//for (Conta c : contas) {
		//	System.out.println(c);
		//}
		
		// Outra forma de implementar o loop:		
		for (int i = 0; i < contas.size(); i++) {
			System.out.println(contas.get(i));
		}
	}
	
	int buscarIndiceConta() {
		System.out.print("Numero da Conta: ");
		Scanner s = new Scanner(System.in);
		String n = s.next();
		
		for (int i = 0; i < contas.size(); i++) {
			if (contas.get(i).numero.equals(n)) {
				return i;
			}
		}
		
		return -1;
	}
	
	void removerConta() {
		int indice = buscarIndiceConta();
		
		if (indice >= 0)
			contas.remove(indice);
		else
			System.out.println("Conta inexistente.");
	}
}
