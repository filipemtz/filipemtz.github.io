package banco;

import java.util.Scanner;

public class App {

	public static int menu() {
		System.out.println("Menu de op��es");
		System.out.println("1) Cadastrar uma conta");
		System.out.println("2) Listar contas");
		System.out.println("3) Remover conta");
		System.out.println("0) Sair");
		System.out.print("Escolha uma opcao: ");
		
		Scanner s = new Scanner(System.in);
		int opcao = s.nextInt();
		
		return opcao;
	}
	
	public static void main(String[] args) {
		Banco b = new Banco();
		
		while (true) {
			int opcao = menu();
			
			if (opcao == 1) {
				b.cadastrarConta();
			}
			else if (opcao == 2) {
				b.listarContas();
			}
			else if (opcao == 3) {
				b.removerConta();
			}
			else if (opcao == 0) {
				// encerrar
				break;
			}
			else {
				System.out.println("Opcao invalida.");
			}
		}
	}
}
