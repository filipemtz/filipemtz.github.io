
public class Cliente {
    String nome;
    String cpf;
    char genero;
    int idade;

    public Cliente(String n, String c, char g, int i) {
        nome = n;
        cpf = c;
        genero = g;
        idade = i;
    }

    public String toString() {
        return "Cliente(" + nome + ", cpf=" + cpf + ", genero=" + genero + ", idade=" + idade + ")";
    }
}
