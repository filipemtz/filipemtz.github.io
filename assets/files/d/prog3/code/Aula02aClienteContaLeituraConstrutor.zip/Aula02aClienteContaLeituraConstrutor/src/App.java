import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        // Criacao do scanner para ler dados do teclado
        Scanner scanner = new Scanner(System.in);

        // Leitura de dados para cadastro do cliente
        System.out.println("-- Cadastro do cliente --");

        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("CPF: ");
        String cpf = scanner.next();

        System.out.print("Genero (m ou f): ");
        char genero = scanner.next().charAt(0);

        System.out.print("Idade: ");
        int idade = scanner.nextInt();

        // Construcao do cliente
        Cliente cliente = new Cliente(nome, cpf, genero, idade);
        System.out.println("Cliente cadastrado: " + cliente + "\n");

        // Construcao da conta corrente do cliente
        ContaCorrente cc = new ContaCorrente(cliente);
        System.out.println("Conta Corrente Criada: " + cc);
        System.out.println("Saldo disponivel: " + cc.disponivel() + "\n");

        // Demonstracao de uso do metodo deposito
        System.out.print("Valor a ser Depositado: ");
        double valor = scanner.nextDouble();
        cc.deposito(valor);
        System.out.println("Saldo apos Deposito: " + cc.disponivel() + "\n");

        scanner.close();
    }
}
