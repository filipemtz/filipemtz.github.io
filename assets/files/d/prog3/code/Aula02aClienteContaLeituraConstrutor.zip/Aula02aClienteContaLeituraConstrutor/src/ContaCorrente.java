
public class ContaCorrente {
    static final double LIMITE_PADRAO = 100;

    Cliente titular;
    double saldo;
    double limite;

    ContaCorrente(Cliente t, double s, double l) {
        titular = t;
        saldo = s;
        limite = l;
    }

    ContaCorrente(Cliente t) {
        titular = t;
        saldo = 0;
        limite = LIMITE_PADRAO;
    }

    double disponivel() {
        return saldo + limite;
    }

    boolean saque(double valor) {
        if ((valor > 0) && (valor < disponivel())) {
            saldo -= valor;
            return true;
        } else {
            System.out.println("Valor invalido de saque.");
            return false;
        }
    }

    boolean deposito(double valor) {
        if (valor > 0) {
            saldo += valor;
            return true;
        } else {
            System.out.println("Valor de deposito invalido.");
            return false;
        }
    }

    public String toString() {
        return "ContaCorrente(saldo=" + saldo + ", limite=" + limite + ", titular=" + titular + ")";
    }
}
