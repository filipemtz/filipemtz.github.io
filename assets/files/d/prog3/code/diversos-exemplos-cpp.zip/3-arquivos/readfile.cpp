
#include <iomanip>
#include <string>
#include <iostream>
#include <fstream>


int 
main() 
{
    std::ifstream file;
    
    file.open("arquivo.txt");
    
    if (!file.is_open())
    {
        std::cerr << "Arquivo nao pode ser aberto." << std::endl; 
        return 0;
    }

    std::string nome, line;
    float peso;

    getline(file, line);
    file >> line >> line >> line >> nome;
    file >> line >> line >> line >> peso;
    
    file.close();

    std::cout << "Nome: " << nome << std::endl;
    std::cout << "Peso: " << peso << std::endl;
    std::cout << "Ultimo valor de line: " << line << std::endl;

    return 0;
}


