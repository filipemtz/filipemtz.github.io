
#include <iomanip>
#include <string>
#include <iostream>
#include <fstream>


int 
main() 
{
    std::ofstream file;
    
    file.open("arquivo.txt");
    
    if (!file.is_open())
    {
        std::cerr << "Arquivo nao pode ser aberto." << std::endl; 
        return 0;
    }

    std::string nome = "filipe";
    float peso = 117;

    file << "ola, esse eh meu arquivo" << std::endl; 
    file << "meu nome eh " << nome << std::endl;
    file << "minha altura eh " << std::fixed << std::setprecision(2) << peso << std::endl;

    file.close();
    
    return 0;
}