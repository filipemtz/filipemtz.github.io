
#include <stdio.h>
#include "ponto.h"

int main()
{
    Ponto2d v1(10, 5);
    Ponto2d v2(7, 12);

    // por baixo dos panos, a expressao v1 + v2 eh v1.operator+(v2)
    Ponto2d v3 = v1 + v2;

    // como distancia eh um metodo estatico, ele eh invocado usando a sintaxe
    // Ponto2d::distancia.
    double dist = Ponto2d::distancia(v1, v2);

    printf("v3.x: %.2lf v3.y: %.2lf dist: %.2lf\n", v3.x, v3.y, dist);

    return 0;
}