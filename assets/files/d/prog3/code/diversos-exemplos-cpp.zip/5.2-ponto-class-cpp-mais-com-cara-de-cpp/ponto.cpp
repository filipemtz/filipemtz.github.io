
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ponto.h"

Ponto2d::Ponto2d(double x, double y)
{
    this->x = x;
    this->y = y;
}

Ponto2d Ponto2d::operator+(const Ponto2d &b)
{
    Ponto2d saida(0, 0);
    saida.x = x + b.x;
    saida.y = y + b.y;
    return saida;
}

double Ponto2d::distancia(const Ponto2d &p1, const Ponto2d &p2)
{
    return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}