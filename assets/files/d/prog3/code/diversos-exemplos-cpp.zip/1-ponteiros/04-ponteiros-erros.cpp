
#include <cstdio>

int main()
{
    int v2[4];
    int v1[4];

    for (int i = 0; i < 8; i++)
        v1[i] = i;

    for (int i = 0; i < 4; i++)
        printf("v1[%d]: %d v2[%d]: %d\n", i, v1[i], i, v2[i]);

    return 0;
}