
#include <cstdio>

int main(int argc, char **argv)
{
    int x = 3;
    int y = 5;
    int *z = &x;
    *z = 7;
    (*z)++;
    int *w = &y;
    ++(*w);
    (*z) = (*w) * (*z);
    char c[4] = {1, 2, 3, 4};
    int *j = (int *)(&c[0]);
    *j = 0;

    printf("x: %d y: %d z: %d w: %d\n", x, y, *z, *w);
    for (int i = 0; i < 4; i++)
        printf("c[%d]: %d\n", i, c[i]);

    return 0;
}