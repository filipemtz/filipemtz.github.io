
#include <cstdio>

int main()
{
    int *a = (int *)1382;
    char *b = (char *)1382;
    a = a + 2;
    b = b + 2;
    a = a - 1;
    b = b - 1;
    printf("a: %d b: %d\n", a, b);

    char c[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    int *p1 = (int *)c;
    char *p2 = (char *)c;

    *(p2 + 1) = 0;
    *(p1 + 1) = 0;

    for (int i = 0; i < 8; i++)
        printf("c[%d]: %d\n", i, c[i]);

    return 0;
}