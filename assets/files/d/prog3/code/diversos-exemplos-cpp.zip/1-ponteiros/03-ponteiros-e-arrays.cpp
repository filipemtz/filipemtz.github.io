
#include <cstdio>

int main()
{
    char c[6] = {1, 2, 3, 4, 5, 6};
    char d[6];
    int e[6];

    char *p_c = &c[0];
    char *p_d = &d[0];
    int *p_e = &e[0];

    for (int i = 0; i < 6; i++)
    {
        *(p_e++) = *(p_c + i);
        *(p_d++) = *(p_c + (5 - i));
    }

    for (int i = 0; i < 6; i++)
        printf("c[%d]: %d d[%d]: %d e[%d]: %d\n",
               i, c[i], i, d[i], i, e[i]);
}