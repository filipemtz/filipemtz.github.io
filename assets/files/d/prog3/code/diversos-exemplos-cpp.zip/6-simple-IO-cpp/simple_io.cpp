
#include <iostream>

int main()
{
    std::string nome;
    int idade;
    double altura;

    std::cout << "Digite seu nome: ";
    std::cin >> nome;
    std::cout << "Digite sua idade: ";
    std::cin >> idade;
    std::cout << "Digite sua altura: ";
    std::cin >> altura;

    std::cout << "Valores digitados:" << std::endl;
    std::cout << "Nome:" << nome << std::endl;
    std::cout << "Idade:" << idade << std::endl;
    std::cout << "Altura:" << altura << std::endl;

    return 0;
}
