
#ifndef __PONTO_H__
#define __PONTO_H__

class Ponto2d
{
public:
    double x, y;

    Ponto2d(double x, double y);
    Ponto2d *soma(const Ponto2d *p);
    double distancia(const Ponto2d *p2) const;
};

#endif
