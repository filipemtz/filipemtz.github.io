
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ponto.h"

Ponto2d::Ponto2d(double x, double y)
{
    this->x = x;
    this->y = y;
}

Ponto2d *Ponto2d::soma(const Ponto2d *b)
{
    Ponto2d *saida = new Ponto2d(0, 0);
    saida->x = x + b->x;
    saida->y = y + b->y;
    return saida;
}

double Ponto2d::distancia(const Ponto2d *p2) const
{
    return sqrt(pow(x - p2->x, 2) + pow(y - p2->y, 2));
}