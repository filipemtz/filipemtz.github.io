
#include <string>
#include <cstdio>

class Pessoa
{
    std::string nome;

public:
    Pessoa(std::string nome = "") { printf("construtor invocado\n"); }
    Pessoa(Pessoa &p) { nome = p.nome; }
    Pessoa &operator=(Pessoa &p)
    {
        printf("Operator=\n");
        nome = p.nome;
        return *this;
    }
    ~Pessoa() { printf("destrutor invocado\n"); }
};

int main()
{
    /**
     * Veja no exemplo abaixo quantas vezes e em que locais os constutores
     * e metodos serao invocados.
     */
    printf("Inicio\n");

    if (1)
    {
        printf("Passo 1\n");
        Pessoa p;
        printf("Passo 2\n");
        Pessoa ps[3];
        printf("Passo 3\n");
        Pessoa q = p;
        printf("Passo 4\n");
        q = p;
        printf("Passo 5\n");
    }

    printf("Fim\n");
    return 0;
}
