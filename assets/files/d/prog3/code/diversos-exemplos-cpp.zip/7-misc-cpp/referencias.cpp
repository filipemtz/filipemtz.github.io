
#include <iostream>

class Ponto
{
public:
    double x;
    Ponto(double x)
    {
        this->x = x;
    }
};

void f(Ponto ponto)
{
    ponto.x = 50;
}

void g(Ponto &ponto)
{
    ponto.x = 50;
}

int main()
{
    Ponto p(7);

    f(p);
    std::cout << "Apos chamar a f: " << p.x << std::endl;

    g(p);
    std::cout << "Apos chamar a g: " << p.x << std::endl;

    return 0;
}
