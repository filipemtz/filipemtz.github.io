
#include <vector>
#include <iostream>

using namespace std;

int main()
{
    std::vector<int> *v = new std::vector<int>;

    v->push_back(1);
    v->push_back(2);
    v->push_back(3);

    // (*v)[1] eh equivalente a fazer v->at(1)
    std::cout << v->at(0) << " " << (*v)[1] << " " << v->at(2) << std::endl;

    delete v;
    return 0;
}