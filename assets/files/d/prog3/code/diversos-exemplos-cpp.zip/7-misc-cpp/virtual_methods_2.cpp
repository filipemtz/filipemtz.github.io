
#include <iostream>

class Funcionario
{
public:
    // remova o virtual na funcao abaixo e observe como o comportamento do
    // programa muda
    virtual double salario() { return 1000; }
};

class Medico : public Funcionario
{
public:
    double salario() { return 2000; }
};

int main()
{
    Funcionario *f = new Medico();
    std::cout << "Salario: " << f->salario() << std::endl;
    return 0;
}