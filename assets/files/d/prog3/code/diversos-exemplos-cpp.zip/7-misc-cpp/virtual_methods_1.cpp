
#include <cstdio>

class A
{
public:
    // Execute o programa com cada uma das versoes abaixo e observe o efeito.
    // O virtual "ativa" a ligacao dinamica.
    //
    // * Versao 1
    // virtual void f()
    // * Versao 2
    void f()
    {
        printf("Fn A\n");
    }
};

class B : public A
{
public:
    void f()
    {
        printf("Fn B\n");
    }
};

int main()
{
    /**
     * Observe como o comportamento do programa muda ao adicionar o virtual
     * na classe A.
     */
    A *a = new A;
    B *b = new B;
    A *c = new B;

    a->f();
    b->f();
    c->f();

    return 0;
}
