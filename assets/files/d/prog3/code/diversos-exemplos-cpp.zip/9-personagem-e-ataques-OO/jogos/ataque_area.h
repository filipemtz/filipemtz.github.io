
#include "ataque.h"

class AtaqueArea : public Ataque
{
    int raio;

public:
    AtaqueArea(const char *nome, int dano, int raio,
               const char *descricao = NULL)
        : Ataque(nome, dano, descricao)
    {
        this->raio = raio;
    }

    void use();
};