
#include <iostream>
#include "ataque_area.h"

using namespace std;

void AtaqueArea::use()
{
    cout << "Ataque de area " << nome << " utilizado." << endl;
}