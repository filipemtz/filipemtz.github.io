
#pragma once

#include <cstdlib>

class Ataque
{
protected:
    const char *nome;
    int dano;
    const char *descricao;

public:
    Ataque(const char *nome, int dano, const char *descricao = NULL);
    virtual void use() = 0;
};
