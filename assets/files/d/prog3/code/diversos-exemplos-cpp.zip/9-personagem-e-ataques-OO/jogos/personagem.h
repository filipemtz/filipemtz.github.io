
#include "ataque.h"
#include <vector>

class Personagem
{
    const char *nome;

public:
    std::vector<Ataque *> *ataques;

    Personagem(const char *nome);
    ~Personagem();
};