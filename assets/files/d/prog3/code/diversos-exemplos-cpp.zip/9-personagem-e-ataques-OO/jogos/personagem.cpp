
#include "personagem.h"

Personagem::Personagem(const char *nome)
{
    this->nome = nome;
    this->ataques = new std::vector<Ataque *>();
}

Personagem::~Personagem()
{
    delete this->ataques;
}
