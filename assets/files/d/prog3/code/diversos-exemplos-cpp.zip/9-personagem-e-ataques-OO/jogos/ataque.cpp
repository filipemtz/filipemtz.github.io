
#include "ataque.h"

Ataque::Ataque(const char *nome, int dano,
               const char *descricao)
{
    this->nome = nome;
    this->dano = dano;
    this->descricao = descricao;
}