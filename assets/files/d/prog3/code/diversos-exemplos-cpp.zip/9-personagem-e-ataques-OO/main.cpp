#include <vector>
#include <iostream>
//#include "jogos/ataque.h"
#include "jogos/ataque_area.h"
#include "jogos/personagem.h"

int main()
{
    AtaqueArea *a = new AtaqueArea("poison", 10, 5);
    Personagem *p = new Personagem("Ryu");

    p->ataques->push_back(new AtaqueArea("magia a", 1, 1));
    p->ataques->push_back(new AtaqueArea("magia b", 2, 2));

    a->use();
    p->ataques->at(0)->use();
    p->ataques->at(1)->use();

    delete a;
    delete p;

    return 0;
}