
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ponto.h"

Ponto2d *ponto2d_construir()
{
    Ponto2d *v = (Ponto2d *)malloc(1 * sizeof(Ponto2d));
    return v;
}

void ponto2d_destruir(Ponto2d *v)
{
    free(v);
}

Ponto2d *ponto2d_soma(Ponto2d *a, Ponto2d *b)
{
    Ponto2d *saida = ponto2d_construir();
    saida->x = a->x + b->x;
    saida->y = a->y + b->y;
    return saida;
}

double ponto2d_distancia(Ponto2d *a, Ponto2d *b)
{
    return sqrt(pow(a->x - b->x, 2) +
                pow(a->y - b->y, 2));
}