
#ifndef __PONTO_H__
#define __PONTO_H__

typedef struct
{
    double x;
    double y;
} Ponto2d;

Ponto2d *ponto2d_construir();
void ponto2d_destruir(Ponto2d *v);
Ponto2d *ponto2d_soma(Ponto2d *a, Ponto2d *b);
double ponto2d_distancia(Ponto2d *a, Ponto2d *b);

#endif
