
#include <stdio.h>
#include "ponto.h"

int main()
{
    Ponto2d *v1 = ponto2d_construir();

    v1->x = 10;
    v1->y = 5;

    Ponto2d *v2 = ponto2d_construir();

    v2->x = 7;
    v2->y = 12;

    Ponto2d *v3 = ponto2d_soma(v1, v2);
    double dist = ponto2d_distancia(v1, v2);

    printf("v3->x: %.2lf v3->y: %.2lf dist: %.2lf\n",
           v3->x, v3->y, dist);

    ponto2d_destruir(v1);
    ponto2d_destruir(v2);
    ponto2d_destruir(v3);

    return 0;
}