
#include <vector>

int main()
{
    std::vector<int> *v = new std::vector<int>();

    // adiciona os itens ao final
    v->push_back(1);
    v->push_back(2);
    v->push_back(3);

    for (int i = 0; i < v->size(); i++)
        printf("%d\n", v->at(i));

    v->pop_back(); // remove o ultimo elemento
    v->clear();    // remove todos os elementos

    return 0;
}