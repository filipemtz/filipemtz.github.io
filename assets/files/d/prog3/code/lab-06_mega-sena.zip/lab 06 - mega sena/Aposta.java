import java.util.ArrayList;
import java.util.Scanner;

public class Aposta {
    Participante organizador;
    ArrayList<Participante> outros_participantes;
    ArrayList<Integer> numeros; 

    Aposta() {
        numeros = new ArrayList<>();
        outros_participantes = new ArrayList<>();

        Scanner s = new Scanner(System.in);

        System.out.println("Numero de participantes alem do organizador: ");
        int n_participantes = s.nextInt(); 

        System.out.println("\n-- Cadastro do Organizador --");
        organizador = new Participante();

        for (int i = 0; i < n_participantes; i++) {
            System.out.println("\n-- Cadastro do Participante " + (i + 1) + " --");
            outros_participantes.add(new Participante());
        }

        System.out.println("\nQuantidade de numeros apostados: ");
        int qtd_numeros = s.nextInt();

        for (int i = 0; i < qtd_numeros; i++) {
            System.out.print("Informe o numero apostado " + (i + 1) + ": ");
            numeros.add(s.nextInt());
        }
    }

    boolean vencedora(ArrayList<Integer> sorteados) {
        for (int n : sorteados) {
            if (!numeros.contains(n))
                return false;
        }
        return true;
    }

    double custo() {
        double valor = 10;

        for (int i = 7; i <= numeros.size(); i++)
            valor += Math.pow(3, i - 6);

        return valor;        
    }
}
