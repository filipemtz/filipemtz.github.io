public class App {
    public static void main(String args[]) {
        Sorteio s = new Sorteio();

        s.registrarApostas();
        s.sortearNumeros();
        s.identificarVencedores();
        s.exibirPremios();
    }
}
