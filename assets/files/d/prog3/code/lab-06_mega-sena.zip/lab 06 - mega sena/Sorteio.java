import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Sorteio {
    ArrayList<Aposta> apostas;
    ArrayList<Integer> numeros_sorteados; 
    ArrayList<Aposta> vencedoras;

    Sorteio() {
        apostas = new ArrayList<>();
        numeros_sorteados = new ArrayList<>();
        vencedoras = new ArrayList<>();
    }

    void registrarApostas() {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Numero de apostas: ");
        int n = s.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.println("-- Cadastro da Aposta " + (i + 1) + ":");
            apostas.add(new Aposta());
        }
    }

    void identificarVencedores() {
        for (Aposta a : apostas) {
            if (a.vencedora(numeros_sorteados))
                vencedoras.add(a);
        }
    }

    double premioTotal() {
        double premio = 0;

        for (Aposta a : apostas)
            premio += a.custo();

        return premio;
    }

    void exibirPremios() {
        System.out.println("\n-- Vencedores --");

        if (vencedoras.size() > 0){
            double premio_aposta = (premioTotal() * 0.9) / vencedoras.size();
    
            for (Aposta a : vencedoras) {
                double premio_participantes = (premio_aposta * 0.9) / (a.outros_participantes.size() + 1);
                double premio_organizador = (premio_aposta * 0.1) + premio_participantes;
    
                System.out.println(
                    a.organizador.nome + " (" + a.organizador.cpf + "): " +
                    "R$ " + premio_organizador
                );
    
                for (Participante p : a.outros_participantes) {
                    System.out.println(
                        p.nome + " (" + p.cpf + "): " +
                        "R$ " + premio_participantes
                    );
                }
            }
        }
        else {
            System.out.println("Não existem apostas vencedoras.");
            System.out.println("Prêmio acumulado de R$ " + premioTotal());
        }
    }

    void sortearNumeros() {
        numeros_sorteados.clear();  // para o caso de ja terem sido sorteados.

        Random rand = new Random();
        for (int i = 0; i < 6; i++) {
            numeros_sorteados.add(i);
            continue;

            /* int novo_numero = rand.nextInt(
                1, 60);
            
            while (numeros_sorteados.contains(novo_numero)) {
                novo_numero = rand.nextInt(
                        1, 60);
            }

            numeros_sorteados.add(novo_numero); */
        }
    }

}
