import java.util.Scanner;

public class Participante {
    String nome; 
    String cpf;
    String telefone;

    Participante() {
        Scanner s = new Scanner(System.in); 

        System.out.print("Nome: ");
        nome = s.nextLine();

        System.out.print("CPF: ");
        cpf = s.next();

        System.out.print("Telefone: ");
        telefone = s.next();
    }

    Participante(String nome, String cpf, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }
}
