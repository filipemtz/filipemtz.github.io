import java.util.ArrayList;
import java.util.Collections;

public class App {
    public static void main(String[] args) {
        ArrayList<Par> questoes = new ArrayList<>();

        questoes.add(new Par("Q1", 0.7));
        questoes.add(new Par("Q2", 0.2));
        questoes.add(new Par("Q3", 0.8));

        Collections.sort(questoes);
        Collections.reverse(questoes);
        System.out.println(questoes);
    }
}