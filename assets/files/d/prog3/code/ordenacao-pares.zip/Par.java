
public class Par implements Comparable<Par> {
    String nome;
    double taxa_acerto;

    Par(String nome, double taxa_acerto) {
        this.nome = nome;
        this.taxa_acerto = taxa_acerto;
    }

    public String toString() {
        return "Par[" + nome + ", taxa_acerto=" + taxa_acerto + "]";
    }

    public int compareTo(Par p) {
        if (this.taxa_acerto < p.taxa_acerto)
            return -1;
        if (this.taxa_acerto == p.taxa_acerto)
            return 0;
        else
            return 1;
    }
}
