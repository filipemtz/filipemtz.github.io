
#include "pessoa.h"
#include <vector>
#include <fstream> 
#include <iostream>

using namespace std; 

void write_csv(vector<Pessoa*> *pessoas, string nome_arquivo) {
    ofstream f(nome_arquivo);

    for (int i = 0; i < pessoas->size(); i++)
        f << pessoas->at(i)->nome << ";" 
            << pessoas->at(i)->idade << ";" 
            << pessoas->at(i)->cpf << "\n";

    f.close();
}

int main() {
    vector<Pessoa*> *pessoas = new vector<Pessoa*>();

    pessoas->push_back(new Pessoa("jose", 19, "123"));
    pessoas->push_back(new Pessoa("maria", 44, "456"));
    pessoas->push_back(new Pessoa("claudia", 12, "789"));
    pessoas->push_back(new Pessoa("mauro", 72, "092"));

    write_csv(pessoas, "pessoas.csv");

    cout << "Programa encerrado com sucesso." << endl;
    return 0;
}