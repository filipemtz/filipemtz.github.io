
#ifndef _PESSOA_H_
#define _PESSOA_H_

#include <string> 

class Pessoa {
public: 
    std::string nome;
    int idade;
    std::string cpf;

    Pessoa(std::string nome, int idade, std::string cpf) {
        this->nome = nome;
        this->idade = idade;
        this->cpf = cpf;
    }
};

#endif