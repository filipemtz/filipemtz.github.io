

#include "pessoa.h"
#include <vector>
#include <fstream> 
#include <iostream>
#include <sstream>

using namespace std; 


std::vector<std::string>* split(std::string linha, char delimitador) {
    std::vector<std::string> *partes = new std::vector<std::string>();
    std::stringstream linha_stream(linha);
    std::string parte;

    while (getline(linha_stream, parte, delimitador))
        partes->push_back(parte);

    return partes;
}


vector<Pessoa*>* read_csv(string nome_arquivo) {
    vector<Pessoa*> *pessoas = new vector<Pessoa*>();
    ifstream f(nome_arquivo);

    // f.eof() retorna verdadeiro quando o arquivo terminou 
    // (eof = end of file) e false quando ainda existem 
    // dados a serem lidos.
    while (!f.eof()) { 
        std::string nome, cpf, linha;
        int idade;

        f >> linha;

        // no fim do arquivo pode existir uma linha vazia. O condicional 
        // abaixo verifica se este eh o caso.
        if (linha.size() > 0) 
        {
            cout << "linha: " << linha << endl;

            std::vector<std::string> *partes = split(linha, ';');

            nome = partes->at(0);
            idade = stoi(partes->at(1)); // stoi converte string para int
            cpf = partes->at(2);

            pessoas->push_back(new Pessoa(nome, idade, cpf));
        }
    }

    f.close();

    return pessoas;
}


int main() {
    vector<Pessoa*> *pessoas = read_csv("pessoas.csv");

    for (int i = 0; i < pessoas->size(); i++)
        cout << i << " " 
            << pessoas->at(i)->nome << " " 
            << pessoas->at(i)->idade << " " 
            << pessoas->at(i)->cpf << endl;

    cout << "Programa encerrado com sucesso." << endl;
    return 0;
}

