import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        RestaurantManager restaurants = new RestaurantManager();
        DishManager dishes = new DishManager();
        OrderManager orders = new OrderManager();
        AccountManager auth = new AccountManager(restaurants, dishes, orders);

        while (true) {
            int opcao = menu();

            if (opcao == 1)
                register(auth, restaurants, dishes, orders);
            else if (opcao == 2)
                login_and_run_use_cases(auth);
            else if (opcao == 0)
                break;
            else
                System.out.println("Opcao invalida.");
        }
    }

    static int menu() {
        Scanner s = new Scanner(System.in);
        System.out.println("\nMenu Inicial");
        System.out.println("1) Registrar Conta");
        System.out.println("2) Fazer Login");
        System.out.println("0) Sair");
        System.out.print("Opcao: ");
        return s.nextInt();
    }

    static void register(AccountManager auth, RestaurantManager restaurants,
            DishManager dishes, OrderManager orders) {
        Scanner s = new Scanner(System.in);
        System.out.println("name: ");
        String name = s.nextLine();
        System.out.println("password: ");
        String password = s.nextLine();
        System.out.println("email: ");
        String email = s.nextLine();
        System.out.println("role (Admin, Owner, or User): ");
        String role = s.nextLine();

        if (role.equals("Admin"))
            auth.register(new Admin(name, password, email, restaurants, dishes, orders, auth));
        else if (role.equals("Owner"))
            auth.register(new Owner(name, password, email, restaurants, dishes, orders));
        else if (role.equals("User"))
            auth.register(new User(name, password, email, restaurants, dishes, orders));
        else
            System.out.println("Tipo de usuario nao conhecido.");
    }

    static void login_and_run_use_cases(AccountManager auth) {
        Scanner s = new Scanner(System.in);
        System.out.println("email: ");
        String email = s.nextLine();
        System.out.println("password: ");
        String password = s.nextLine();

        Account user = auth.searchByCredentials(email, password);

        if (user != null)
            user.runUseCases();
        else
            System.out.println("Usuario nao encontrado.");
    }
}
