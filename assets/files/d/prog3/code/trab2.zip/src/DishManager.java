import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class DishManager {
    private ArrayList<Dish> lanches = new ArrayList<>();

    public DishManager() {
        load();
    }

    public void register(Dish d) {
        if (searchIdxByCode(d.codigo) == -1) {
            lanches.add(d);
            save();
        } else
            System.out.println("Ja existe um prato com este codigo");
    }

    int numDishes() {
        return lanches.size();
    }

    ArrayList<Dish> sortedByOrderCount(OrderManager orders) {
        ArrayList<DishComparable> comparables = new ArrayList<>();

        for (Dish d : lanches)
            comparables.add(new DishComparable(d, orders.numOrdersByDish(d.codigo)));

        Collections.sort(comparables, Collections.reverseOrder());

        ArrayList<Dish> dishes_sorted = new ArrayList<>();

        for (DishComparable d : comparables)
            dishes_sorted.add(d.dish);

        return dishes_sorted;
    }

    ArrayList<Dish> sortedByTotalValue(OrderManager orders) {
        ArrayList<DishComparable> comparables = new ArrayList<>();

        for (Dish d : lanches)
            comparables.add(new DishComparable(d, orders.totalValueByDish(d)));

        Collections.sort(comparables, Collections.reverseOrder());

        ArrayList<Dish> dishes_sorted = new ArrayList<>();

        for (DishComparable d : comparables)
            dishes_sorted.add(d.dish);

        return dishes_sorted;
    }

    public void removeByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1) {
            lanches.remove(idx);
            save();
        } else
            System.out.println("Restaurante nao encontrado.");

    }

    public Dish searchByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1)
            return lanches.get(idx);
        else
            return null;
    }

    public ArrayList<Dish> searchByName(String search_string) {
        ArrayList<Dish> dishes_match = new ArrayList<>();
        for (int i = 0; i < lanches.size(); i++)
            if (lanches.get(i).descricao.contains(search_string))
                dishes_match.add(lanches.get(i));

        return dishes_match;
    }

    private int searchIdxByCode(int code) {
        for (int i = 0; i < lanches.size(); i++)
            if (lanches.get(i).codigo == code)
                return i;

        return -1;
    }

    public ArrayList<Dish> searchByRestaurant(int restaurant_code) {
        ArrayList<Dish> restaurant_dishes = new ArrayList<>();

        for (Dish d : lanches) {
            if (d.lanchonete == restaurant_code)
                restaurant_dishes.add(d);
        }

        return restaurant_dishes;
    }

    public void removeByRestaurant(int restaurant_code) {
        for (int i = 0; i < lanches.size(); i++)
            if (lanches.get(i).lanchonete == restaurant_code)
                lanches.remove(i);

        save();
    }

    private void save() {
        try {
            FileWriter f = new FileWriter("dishes.csv");
            for (Dish d : lanches)
                f.write(d.codigo + ";" +
                        d.descricao + ";" +
                        d.preco + ";" +
                        d.lanchonete + "\n");
            f.close();
        } catch (IOException e) {
            System.out.println("Arquivo 'dishes.csv' nao pode ser salvo.");
        }
    }

    private void load() {
        try {
            File f = new File("dishes.csv");
            Scanner s = new Scanner(f);

            while (s.hasNextLine()) {
                String line = s.nextLine();
                String parts[] = line.split(";");

                int codigo = Integer.parseInt(parts[0]);
                double preco = Double.parseDouble(parts[2]);
                int lanchonete = Integer.parseInt(parts[3]);

                lanches.add(new Dish(
                        codigo, parts[1], preco, lanchonete));
            }

            s.close();

        } catch (IOException e) {
            System.out.println("Arquivo 'dishes.csv' nao encontrado.");
        }
    }
}
