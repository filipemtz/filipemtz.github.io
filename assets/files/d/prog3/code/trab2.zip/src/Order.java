import java.util.ArrayList;

public class Order {
    int codigo;
    ArrayList<Integer> codigos_produtos;
    ArrayList<Integer> quantidades;
    int restaurant;
    String client_email;

    Order(int codigo, int restaurant, String client_email, ArrayList<Integer> codigos_produtos,
            ArrayList<Integer> quantidades) {
        this.codigo = codigo;
        this.codigos_produtos = codigos_produtos;
        this.quantidades = quantidades;
        this.restaurant = restaurant;
        this.client_email = client_email;
    }

    Order(int codigo, int restaurant, String client_email) {
        this(codigo, restaurant, client_email, new ArrayList<>(), new ArrayList<>());
    }

    public String toString() {
        String output = "Order(codigo=" + codigo + ", restaurant=" + restaurant + ", cliente=" + client_email;
        output += ", codigos_produtos=" + codigos_produtos + ", quantidades=" + quantidades + ")";
        return output;
    }

    void add(int codigo_prato, int quantidade) {
        codigos_produtos.add(codigo_prato);
        quantidades.add(quantidade);
    }

    int numItens() {
        int count = 0;

        for (int i = 0; i < codigos_produtos.size(); i++)
            count += quantidades.get(i);

        return count;
    }

    double precoTotal(DishManager dishes) {
        double total = 0;

        for (int i = 0; i < codigos_produtos.size(); i++) {
            total += dishes.searchByCode(codigos_produtos.get(i)).preco * quantidades.get(i);
        }

        return total;
    }
}
