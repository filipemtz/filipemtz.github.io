public class Restaurant {
    int codigo;
    String nome;
    String endereco;
    String categoria;
    String proprietario;
    private int soma_avaliacoes;
    private int n_avaliacoes;

    Restaurant(int codigo, String nome, String endereco, String categoria, String proprietario) {
        this.codigo = codigo;
        this.nome = nome;
        this.endereco = endereco;
        this.categoria = categoria;
        this.proprietario = proprietario;
        this.soma_avaliacoes = 0;
        this.n_avaliacoes = 0;
    }

    public String toString() {
        return nome + " (codigo=" + codigo + "categoria=" + categoria + ", proprietario=" + proprietario
                + ", pontuacao_media="
                + pontuacaoMedia() + ")";
    }

    public void setSomaPontuacao(int soma_avaliacoes) {
        this.soma_avaliacoes = soma_avaliacoes;
    }

    public void setContadorAvaliacoes(int n_avaliacoes) {
        this.n_avaliacoes = n_avaliacoes;
    }

    public int getSomaAvaliacoes() {
        return soma_avaliacoes;
    }

    public int getNumAvaliacoes() {
        return n_avaliacoes;
    }

    public void adicionarAvaliacao(int val) {
        if (val >= 0 && val <= 5) {
            soma_avaliacoes += val;
            n_avaliacoes++;
        } else {
            System.out.println("A pontuacao deve estar entre 0 e 5. Avaliacao ignorada.");
        }
    }

    public double pontuacaoMedia() {
        if (n_avaliacoes == 0)
            return 0;
        else
            return (double) soma_avaliacoes / (double) n_avaliacoes;
    }
}
