import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class AccountManager {
    ArrayList<Account> users = new ArrayList<>();
    RestaurantManager restaurants;
    DishManager dishes;
    OrderManager orders;

    AccountManager(RestaurantManager restaurants, DishManager dishes, OrderManager orders) {
        this.restaurants = restaurants;
        this.dishes = dishes;
        this.orders = orders;
        load();
    }

    public int numAccounts() {
        return users.size();
    }

    public void register(Account user) {
        if (searchIdxByEmail(user.getEmail()) == -1) {
            users.add(user);
            save();
        } else
            System.out.println("Ja existe um usuario com este e-mail. Ignorando o cadastro.");
    }

    public void removeByEmail(String email) {
        int idx = searchIdxByEmail(email);

        if (idx != -1) {
            users.remove(idx);
            save();
        } else
            System.out.println("Usuario com email '" + email + "' nao encontrado.");
    }

    public Account searchByCredentials(String email, String password) {
        int idx = searchIdxByEmail(email);

        if (idx != -1)
            if (users.get(idx).hasValidCredentials(email, password))
                return users.get(idx);

        return null;
    }

    private int searchIdxByEmail(String email) {
        for (int i = 0; i < users.size(); i++)
            if (users.get(i).getEmail().equals(email))
                return i;

        return -1;
    }

    public ArrayList<Account> searchByRole(String role) {
        ArrayList<Account> selected_accounts = new ArrayList<>();
        for (int i = 0; i < users.size(); i++)
            if (users.get(i).role().equals(role))
                selected_accounts.add(users.get(i));

        return selected_accounts;
    }

    public ArrayList<Account> sortedByNumOrders(OrderManager orders) {
        Collections.sort(users, new AccountNumOrdersComparator(orders));
        return users;
    }

    public ArrayList<Account> sortedByValueSpent(OrderManager orders, DishManager dishes) {
        Collections.sort(users, new AccountValueSpentComparator(orders, dishes));
        return users;
    }

    private void save() {
        try {
            FileWriter f = new FileWriter("users.csv");
            for (Account u : users)
                f.write(u.role() + ";" + u.getEmail() + ";" + u.getPassword() + ";" + u.getName() + "\n");
            f.close();
        } catch (IOException e) {
            System.out.println("Arquivo 'users.csv' nao pode ser salvo.");
        }
    }

    private void load() {
        try {
            File f = new File("users.csv");
            Scanner s = new Scanner(f);

            while (s.hasNextLine()) {
                String line = s.nextLine();
                String parts[] = line.split(";");

                if (parts[0].equals("Admin"))
                    users.add(new Admin(parts[3], parts[2], parts[1], restaurants, dishes, orders, this));
                else if (parts[0].equals("User"))
                    users.add(new User(parts[3], parts[2], parts[1], restaurants, dishes, orders));
                else if (parts[0].equals("Owner"))
                    users.add(new Owner(parts[3], parts[2], parts[1], restaurants, dishes, orders));
                else
                    System.out.println("Role '" + parts[0] + "' not found.");
            }

            s.close();

        } catch (IOException e) {
            System.out.println("Arquivo 'users.csv' nao encontrado.");
        }
    }
}
