
public class RestaurantScoreComparable implements Comparable<RestaurantScoreComparable> {
    public Restaurant restaurant;

    public RestaurantScoreComparable(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    @Override
    public int compareTo(RestaurantScoreComparable o) {
        double r_score = restaurant.pontuacaoMedia();
        double o_score = o.restaurant.pontuacaoMedia();

        if (r_score < o_score)
            return -1;
        else if (r_score == o_score)
            return 0;
        else
            return 1;
    }
}
