import java.util.ArrayList;

public class RestaurantOrderCountComparable implements Comparable<RestaurantOrderCountComparable> {
    public Restaurant restaurant;
    private int sum_sellings;

    public RestaurantOrderCountComparable(Restaurant restaurant, ArrayList<Order> orders_of_restaurant) {
        this.restaurant = restaurant;
        sum_sellings = 0;

        for (Order o : orders_of_restaurant)
            sum_sellings += o.numItens();
    }

    @Override
    public int compareTo(RestaurantOrderCountComparable o) {
        double r_score = sum_sellings;
        double o_score = o.sum_sellings;

        if (r_score < o_score)
            return -1;
        else if (r_score == o_score)
            return 0;
        else
            return 1;
    }
}
