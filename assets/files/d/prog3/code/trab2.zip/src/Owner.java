import java.util.ArrayList;

public class Owner extends Account {
    public Owner(String name, String password, String email, RestaurantManager restaurants, DishManager dishes,
            OrderManager orders) {
        super(name, password, email, restaurants, dishes, orders);
    }

    public String role() {
        return "Owner";
    }

    protected int menu() {
        System.out.println("\nMenu Proprietario");
        System.out.println("1) Cadastrar lanchonete");
        System.out.println("2) Ver lanchonetes");
        System.out.println("3) Remover lanchonete");
        System.out.println("4) Cadastrar lanches");
        System.out.println("5) Ver lanches");
        System.out.println("6) Ver pedidos");
        System.out.println("7) Ver detalhe de pedido");
        System.out.println("8) Remover pedido");
        System.out.println("0) Sair");
        System.out.print("Opcao: ");
        return s.nextInt();
    }

    protected void executeOption(int opcao) {
        if (opcao == 1)
            cadastrarLanchonete();
        else if (opcao == 2)
            verLanchonetes();
        else if (opcao == 3)
            removerLanchonete();
        else if (opcao == 4)
            cadastrarLanche();
        else if (opcao == 5)
            verLanches();
        else if (opcao == 6)
            verPedidos();
        else if (opcao == 7)
            verDetalhePedido();
        else if (opcao == 8)
            removerPedido();
        else
            System.out.println("Opcao invalida.");
    }

    private void cadastrarLanchonete() {
        System.out.println("codigo:");
        int codigo = s.nextInt();
        s.nextLine();
        System.out.println("nome:");
        String nome = s.nextLine();
        System.out.println("endereco:");
        String endereco = s.nextLine();
        System.out.println("categoria:");
        String categoria = s.nextLine();

        Restaurant r = new Restaurant(codigo, nome, endereco, categoria, getEmail());
        restaurants.register(r);
    }

    private void verLanchonetes() {
        ArrayList<Restaurant> rs = restaurants.searchByOwner(getEmail());

        if (rs.size() == 0)
            System.out.println("Nao existem restaurantes cadastrados.");
        else
            for (Restaurant r : rs)
                System.out.println(r.codigo + " - " + r.nome);
    }

    private void removerLanchonete() {
        System.out.print("Codigo: ");
        int codigo = s.nextInt();
        restaurants.removeByCode(codigo);
        dishes.removeByRestaurant(codigo);
        orders.removeByRestaurant(codigo);
    }

    private void cadastrarLanche() {
        System.out.print("Codigo do lanche: ");
        int codigo = s.nextInt();
        s.nextLine();

        System.out.print("Descricao do lanche: ");
        String descricao = s.nextLine();

        System.out.print("Preco do lanche: ");
        double preco = s.nextDouble();

        System.out.print("Codigo do lanchonete: ");
        int lanchonete = s.nextInt();

        dishes.register(new Dish(codigo, descricao, preco, lanchonete));
    }

    private void verLanches() {
        System.out.print("Codigo do lanchonete: ");
        int lanchonete = s.nextInt();

        ArrayList<Dish> dishes_restaurant = dishes.searchByRestaurant(lanchonete);

        if (dishes_restaurant.size() == 0)
            System.out.println("\nNao existem lanches cadastrados.");
        else
            for (Dish d : dishes_restaurant)
                System.out.println(d);
    }

    private void verPedidos() {
        System.out.print("Codigo do lanchonete: ");
        int restaurant_code = s.nextInt();

        ArrayList<Order> orders_restaurant = orders.searchByRestaurant(restaurant_code);

        if (orders_restaurant.size() == 0)
            System.out.println("\nNao existem pedidos cadastrados.");
        else
            for (Order o : orders_restaurant)
                System.out.println(o);
    }

    private void verDetalhePedido() {
        System.out.print("Codigo do pedido: ");
        int order_code = s.nextInt();

        /**
         * TERMINAR! Exibir dados detalhados do pedido.
         */
        Order o = orders.searchByCode(order_code);
        System.out.println(o);
    }

    private void removerPedido() {
        System.out.print("Codigo do pedido: ");
        int order_code = s.nextInt();
        orders.removeByCode(order_code);
    }

}
