import java.util.Comparator;

public class AccountValueSpentComparator implements Comparator<Account> {
    OrderManager orders;
    DishManager dishes;

    AccountValueSpentComparator(OrderManager orders, DishManager dishes) {
        this.orders = orders;
        this.dishes = dishes;
    }

    public int compare(Account a1, Account a2) {
        double val_1 = orders.totalValueByClient(a1.email, dishes);
        double val_2 = orders.totalValueByClient(a2.email, dishes);

        if (val_1 < val_2)
            return 1;
        else if (val_1 == val_2)
            return 0;
        else
            return -1;
    }
}
