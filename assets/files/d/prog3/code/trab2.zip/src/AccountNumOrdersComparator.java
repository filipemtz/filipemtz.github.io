import java.util.Comparator;

public class AccountNumOrdersComparator implements Comparator<Account> {
    OrderManager orders;

    AccountNumOrdersComparator(OrderManager orders) {
        this.orders = orders;
    }

    public int compare(Account a1, Account a2) {
        return orders.searchByClient(a2.email).size() - orders.searchByClient(a1.email).size();
    }
}
