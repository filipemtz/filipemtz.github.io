import java.util.ArrayList;

public class Admin extends Account {
    AccountManager accounts;

    public Admin(String name, String password, String email, RestaurantManager restaurants, DishManager dishes,
            OrderManager orders, AccountManager accounts) {
        super(name, password, email, restaurants, dishes, orders);
        this.accounts = accounts;
    }

    public String role() {
        return "Admin";
    }

    protected int menu() {
        System.out.println("\nMenu Admin");
        System.out.println("1) Relatorio de Quantidades");
        System.out.println("2) Relatorio de Vendas");
        System.out.println("3) Relatorio de Desempenho");
        System.out.println("0) Sair");
        System.out.print("Opcao: ");
        return s.nextInt();
    }

    protected void executeOption(int opcao) {
        if (opcao == 1)
            verRelatorioQuantidades();
        else if (opcao == 2)
            verRelatorioVendas();
        else if (opcao == 3)
            verRelatorioDesempenho();
        else
            System.out.println("Opcao invalida.");
    }

    private void verRelatorioQuantidades() {
        System.out.println("\nRelatorio de Quantidades: ");
        System.out.println("Numero de clientes: " + accounts.searchByRole("User").size());
        System.out.println("Numero de restaurantes: " + restaurants.numRestaurants());
        System.out.println("Numero de lanches: " + dishes.numDishes());
        System.out.println("Numero de pedidos: " + orders.numOrders());
        System.out.println("Valor das vendas: " + orders.totalOrderValues(dishes));
    }

    private void verRelatorioVendas() {
        /*
         * Visualizar relatório de vendas com os 5 lanches mais vendidos considerando
         * todas as lojas, os 5 lanches que levaram à um maior faturamento, as 5
         * lojas que mais venderam, as 5 lojas que mais faturaram, os 5 clientes
         * que mais compraram e os clientes que mais gastaram em compras.
         */
        int n;

        System.out.println("\n5 Pratos que mais venderam:");
        ArrayList<Dish> dishes_by_orders = dishes.sortedByOrderCount(orders);
        if (dishes_by_orders.size() == 0)
            System.out.println("Sem pedidos cadastrados.");
        else {
            n = Math.min(dishes_by_orders.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(dishes_by_orders.get(i));
        }

        System.out.println("\n5 Pratos que mais geraram lucros:");
        ArrayList<Dish> dishes_by_profit = dishes.sortedByTotalValue(orders);
        if (dishes_by_profit.size() == 0)
            System.out.println("Sem pedidos cadastrados.");
        else {
            n = Math.min(dishes_by_profit.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(dishes_by_profit.get(i));
        }

        System.out.println("\n5 Restaurantes que mais venderam:");
        ArrayList<Restaurant> rs = restaurants.sortedByNumOrders(orders);
        if (rs.size() == 0)
            System.out.println("Sem restaurantes cadastrados.");
        else {
            n = Math.min(rs.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(rs.get(i));
        }

        System.out.println("\n5 Restaurantes que mais faturaram:");
        rs = restaurants.sortedByTotalValue(orders, dishes);
        if (rs.size() == 0)
            System.out.println("Sem restaurantes cadastrados.");
        else {
            n = Math.min(rs.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(rs.get(i));
        }

        System.out.println("\n5 clientes que mais compraram:");
        ArrayList<Account> accounts_by_orders = accounts.sortedByNumOrders(orders);
        accounts_by_orders = selectByRole(accounts_by_orders, "User");
        if (accounts_by_orders.size() == 0)
            System.out.println("Nao existem usuarios cadastrados ainda.");
        else {
            n = Math.min(accounts_by_orders.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(accounts_by_orders.get(i));
        }

        System.out.println("\n5 clientes que mais gastaram:");
        ArrayList<Account> accounts_by_val = accounts.sortedByValueSpent(orders, dishes);
        accounts_by_val = selectByRole(accounts_by_val, "User");
        if (accounts_by_val.size() == 0)
            System.out.println("Nao existem usuarios cadastrados ainda.");
        else {
            n = Math.min(accounts_by_val.size(), 5);
            for (int i = 0; i < n; i++)
                System.out.println(accounts_by_val.get(i));
        }

    }

    private ArrayList<Account> selectByRole(ArrayList<Account> account_list, String role) {
        ArrayList<Account> accounts_by_role = new ArrayList<>();

        for (Account a : account_list)
            if (a.role().equals(role))
                accounts_by_role.add(a);

        return accounts_by_role;
    }

    private void verRelatorioDesempenho() {
        if (restaurants.numRestaurants() == 0)
            System.out.println("\nAinda nao existem restaurantes cadastrados.");
        else {
            for (Restaurant r : restaurants.restaurants) {
                ArrayList<Order> orders_restaurant = orders.searchByRestaurant(r.codigo);
                System.out.println("\nRestaurant: " + r.nome);
                System.out.println("Numero medio de produtos por pedido: " + avgNumProductsPerOrder(orders_restaurant));
                System.out.println("Valor medio por produto vendido: " + avgProductValueInOrders(orders_restaurant));
                System.out.println("Valor medio por pedido: " + avgOrderValue(orders_restaurant));
            }
        }
    }

    private double avgNumProductsPerOrder(ArrayList<Order> orders_restaurant) {
        int total = 0;

        for (Order o : orders_restaurant) {
            total += o.codigos_produtos.size();
        }

        if (orders_restaurant.size() == 0)
            return 0;
        else
            return (double) total / (double) orders_restaurant.size();
    }

    private double avgProductValueInOrders(ArrayList<Order> orders_restaurant) {
        double total_val = 0;
        int count = 0;

        for (Order o : orders_restaurant) {
            for (int i = 0; i < o.codigos_produtos.size(); i++) {
                total_val += o.quantidades.get(i) * dishes.searchByCode(o.codigos_produtos.get(i)).preco;
                count += o.quantidades.get(i);
            }
        }

        if (count == 0)
            return 0;
        else
            return total_val / count;
    }

    private double avgOrderValue(ArrayList<Order> orders_restaurant) {
        double total = 0;

        for (Order o : orders_restaurant) {
            total += o.precoTotal(dishes);
        }

        if (orders_restaurant.size() == 0)
            return 0;
        else
            return total / orders_restaurant.size();
    }
}
