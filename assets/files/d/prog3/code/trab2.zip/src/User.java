import java.util.ArrayList;

public class User extends Account {
    public User(String name, String password, String email, RestaurantManager restaurants, DishManager dishes,
            OrderManager orders) {
        super(name, password, email, restaurants, dishes, orders);
    }

    public String role() {
        return "User";
    }

    protected int menu() {
        System.out.println("\nMenu Usuario");
        System.out.println("1) Ver lanchonetes por pontuacao");
        System.out.println("2) Ver lanchonetes por categoria");
        System.out.println("3) Ver lanchonetes por preco");
        System.out.println("4) Ver lanchonetes por numero de vendas");
        System.out.println("5) Ver lanches");
        System.out.println("6) Buscar lanche por nome");
        System.out.println("7) Fazer pedido");
        System.out.println("8) Avaliar lanchonete");
        System.out.println("0) Sair");
        System.out.print("Opcao: ");
        return s.nextInt();
    }

    protected void executeOption(int opcao) {
        if (opcao == 1)
            verLanchonetesPorPontuacao();
        else if (opcao == 2)
            verLanchonetesPorCategoria();
        else if (opcao == 3)
            verLanchonetesPorPreco();
        else if (opcao == 4)
            verLanchonetesPorNumeroVendas();
        else if (opcao == 5)
            verLanches();
        else if (opcao == 6)
            buscarLancheNome();
        else if (opcao == 7)
            fazerPedido();
        else if (opcao == 8)
            avaliarLanchonete();
        else
            System.out.println("Opcao invalida.");
    }

    private void verLanchonetesPorPontuacao() {
        ArrayList<Restaurant> rs = restaurants.sortedByScore();
        for (Restaurant r : rs)
            System.out.println(r.nome + " " + r.pontuacaoMedia());
    }

    private void verLanchonetesPorCategoria() {
        s.nextLine();
        System.out.print("Categoria: ");
        String search_string = s.nextLine();
        ArrayList<Restaurant> rs = restaurants.searchByCategory(search_string);
        for (Restaurant r : rs)
            System.out.println(r.nome + " " + r.pontuacaoMedia());
    }

    private void verLanchonetesPorPreco() {

        ArrayList<Restaurant> restaurants_by_price = restaurants.sortedByPrice(dishes);

        for (Restaurant r : restaurants_by_price)
            System.out.println(r.nome);
    }

    private void verLanchonetesPorNumeroVendas() {
        ArrayList<Restaurant> restaurants_by_order_count = restaurants.sortedByNumOrders(orders);

        for (Restaurant r : restaurants_by_order_count)
            System.out.println(r.nome);
    }

    private void verLanches(int restaurant_code) {
        Restaurant r = restaurants.searchByCode(restaurant_code);
        ArrayList<Dish> dishes_restaurant = dishes.searchByRestaurant(restaurant_code);

        System.out.println("Lanchonete");
        System.out.println(r);

        for (Dish d : dishes_restaurant) {
            System.out.println(d);
        }
    }

    private void verLanches() {
        System.out.println("Codigo do restaurante: ");
        int restaurant_code = s.nextInt();
        s.nextLine();
        verLanches(restaurant_code);
    }

    private void buscarLancheNome() {
        s.nextLine();
        System.out.print("Buscar: ");
        String search_string = s.nextLine();
        ArrayList<Dish> selected_dishes = dishes.searchByName(search_string);
        for (Dish d : selected_dishes)
            System.out.println(d);
    }

    private int menuFazerPedido() {
        System.out.println("Menu Fazer Pedido");
        System.out.println("1) Ver produtos da lanchonete");
        System.out.println("2) Adicionar produto");
        System.out.println("0) Sair");
        System.out.print("Opcao: ");
        return s.nextInt();
    }

    public void fazerPedido() {
        System.out.print("Codigo do pedido: ");
        int codigo = s.nextInt();

        System.out.print("Codigo da lanchonete: ");
        int lanchonete = s.nextInt();

        Order o = new Order(codigo, lanchonete, email);

        while (true) {
            int opcao = menuFazerPedido();

            if (opcao == 1)
                verLanches(lanchonete);
            else if (opcao == 2)
                adicionarItem(o);
            else if (opcao == 0)
                break;
            else
                System.out.println("Opcao invalida. Tente novamente.");
        }

        System.out.println("Valor total da compra: " + o.precoTotal(dishes));
        orders.register(o);
    }

    private void adicionarItem(Order o) {
        System.out.print("Codigo do produto: ");
        int codigo_produto = s.nextInt();

        System.out.print("Quantidade: ");
        int quantidade = s.nextInt();

        o.add(codigo_produto, quantidade);
    }

    private void avaliarLanchonete() {
        System.out.print("Codigo da lanchonete: ");
        int code = s.nextInt();

        System.out.print("Avaliacao (0-5): ");
        int nota = s.nextInt();

        s.nextLine();

        restaurants.avaliarRestaurante(code, nota);
    }

}
