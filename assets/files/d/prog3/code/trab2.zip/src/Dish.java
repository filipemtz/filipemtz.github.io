public class Dish {
    int codigo;
    String descricao;
    double preco;
    int lanchonete;

    Dish(int codigo, String descricao, double preco, int lanchonete) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.preco = preco;
        this.lanchonete = lanchonete;
    }

    public String toString() {
        return descricao + " (codigo=" + codigo + ", preco=" + preco + ", lanchonete=" + lanchonete + ")";
    }
}
