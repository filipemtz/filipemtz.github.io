import java.util.ArrayList;

public class RestaurantPriceComparable implements Comparable<RestaurantPriceComparable> {
    public Restaurant restaurant;
    private double avg_price;

    public RestaurantPriceComparable(Restaurant restaurant, ArrayList<Dish> dishes_of_restaurant) {
        this.restaurant = restaurant;
        avg_price = 0;

        for (Dish d : dishes_of_restaurant)
            avg_price += d.preco;

        if (dishes_of_restaurant.size() > 0)
            avg_price /= dishes_of_restaurant.size();
    }

    @Override
    public int compareTo(RestaurantPriceComparable o) {
        double r_score = avg_price;
        double o_score = o.avg_price;

        if (r_score < o_score)
            return -1;
        else if (r_score == o_score)
            return 0;
        else
            return 1;
    }
}
