import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class RestaurantManager {
    ArrayList<Restaurant> restaurants = new ArrayList<>();

    RestaurantManager() {
        load();
    }

    void register(Restaurant r) {
        if (searchIdxByCode(r.codigo) == -1) {
            restaurants.add(r);
            save();
        } else
            System.out.println("Ja existe um restaurante com este codigo. Registro nao feito.");
    }

    int numRestaurants() {
        return restaurants.size();
    }

    int searchIdxByCode(int code) {
        for (int i = 0; i < restaurants.size(); i++)
            if (restaurants.get(i).codigo == code)
                return i;

        return -1;
    }

    ArrayList<Restaurant> searchByOwner(String email) {
        ArrayList<Restaurant> rs = new ArrayList<>();

        for (Restaurant r : restaurants)
            if (r.proprietario.equals(email))
                rs.add(r);

        return rs;
    }

    void removeByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1) {
            restaurants.remove(idx);
            save();
        } else
            System.out.println("Restaurante nao encontrado.");

    }

    Restaurant searchByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1)
            return restaurants.get(idx);
        else
            return null;
    }

    ArrayList<Restaurant> sortedByScore() {
        ArrayList<RestaurantScoreComparable> comparables = new ArrayList<>();

        for (Restaurant r : restaurants)
            comparables.add(new RestaurantScoreComparable(r));

        Collections.sort(comparables, Collections.reverseOrder());

        ArrayList<Restaurant> restaurants_sorted = new ArrayList<>();

        for (RestaurantScoreComparable c : comparables)
            restaurants_sorted.add(c.restaurant);

        return restaurants_sorted;
    }

    ArrayList<Restaurant> sortedByPrice(DishManager dishes) {
        ArrayList<RestaurantPriceComparable> comparables = new ArrayList<>();

        for (Restaurant r : restaurants) {
            ArrayList<Dish> restaurant_dishes = dishes.searchByRestaurant(r.codigo);
            comparables.add(new RestaurantPriceComparable(r, restaurant_dishes));
        }

        Collections.sort(comparables);

        ArrayList<Restaurant> restaurants_by_price = new ArrayList<>();

        for (RestaurantPriceComparable c : comparables)
            restaurants_by_price.add(c.restaurant);

        return restaurants_by_price;
    }

    ArrayList<Restaurant> sortedByNumOrders(OrderManager orders) {
        ArrayList<RestaurantOrderCountComparable> comparables = new ArrayList<>();

        for (Restaurant r : restaurants) {
            ArrayList<Order> restaurant_orders = orders.searchByRestaurant(r.codigo);
            comparables.add(new RestaurantOrderCountComparable(r, restaurant_orders));
        }

        Collections.sort(comparables, Collections.reverseOrder());

        ArrayList<Restaurant> restaurants_by_count = new ArrayList<>();

        for (RestaurantOrderCountComparable c : comparables)
            restaurants_by_count.add(c.restaurant);

        return restaurants_by_count;
    }

    ArrayList<Restaurant> sortedByTotalValue(OrderManager orders, DishManager dishes) {
        ArrayList<RestaurantTotalValueComparable> comparables = new ArrayList<>();

        for (Restaurant r : restaurants) {
            double val = orders.totalValueByRestaurant(r.codigo, dishes);
            comparables.add(new RestaurantTotalValueComparable(r, val));
        }

        Collections.sort(comparables, Collections.reverseOrder());

        ArrayList<Restaurant> restaurants_by_count = new ArrayList<>();

        for (RestaurantTotalValueComparable c : comparables)
            restaurants_by_count.add(c.restaurant);

        return restaurants_by_count;
    }

    ArrayList<Restaurant> searchByCategory(String category) {
        ArrayList<Restaurant> restaurants_sorted = sortedByScore();
        ArrayList<Restaurant> selected_category = new ArrayList<>();

        for (Restaurant r : restaurants_sorted)
            if (r.categoria.equals(category))
                selected_category.add(r);

        return selected_category;
    }

    public void avaliarRestaurante(int codigo, int nota) {
        Restaurant r = searchByCode(codigo);
        r.adicionarAvaliacao(nota);
        save();
    }

    private void save() {
        try {
            FileWriter f = new FileWriter("restaurants.csv");
            for (Restaurant r : restaurants)
                f.write(r.codigo + ";" +
                        r.nome + ";" +
                        r.endereco + ";" +
                        r.categoria + ";" +
                        r.getSomaAvaliacoes() + ";" +
                        r.getNumAvaliacoes() + ";" +
                        r.proprietario + "\n");
            f.close();
        } catch (IOException e) {
            System.out.println("Arquivo 'restaurants.csv' nao pode ser salvo.");
        }
    }

    private void load() {
        try {
            File f = new File("restaurants.csv");
            Scanner s = new Scanner(f);

            while (s.hasNextLine()) {
                String line = s.nextLine();
                String parts[] = line.split(";");
                int codigo = Integer.parseInt(parts[0]);
                int soma_avaliacoes = Integer.parseInt(parts[4]);
                int n_avaliacoes = Integer.parseInt(parts[5]);

                Restaurant r = new Restaurant(
                        codigo,
                        parts[1],
                        parts[2],
                        parts[3],
                        parts[6]);

                r.setSomaPontuacao(soma_avaliacoes);
                r.setContadorAvaliacoes(n_avaliacoes);

                restaurants.add(r);
            }

            s.close();

        } catch (IOException e) {
            System.out.println("Arquivo 'restaurants.csv' nao encontrado.");
        }
    }
}
