
public class DishComparable implements Comparable<DishComparable> {
    public Dish dish;
    private double sorting_value;

    public DishComparable(Dish dishes, double sorting_value) {
        this.dish = dishes;
        this.sorting_value = sorting_value;
    }

    @Override
    public int compareTo(DishComparable o) {
        double r_score = sorting_value;
        double o_score = o.sorting_value;

        if (r_score < o_score)
            return -1;
        else if (r_score == o_score)
            return 0;
        else
            return 1;
    }
}
