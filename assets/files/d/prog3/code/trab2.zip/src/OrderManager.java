import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class OrderManager {
    private ArrayList<Order> orders = new ArrayList<>();

    public OrderManager() {
        load();
    }

    public void register(Order o) {
        if (searchIdxByCode(o.codigo) == -1) {
            orders.add(o);
            save();
        } else
            System.out.println("Ja existe um pedido com este codigo");
    }

    int numOrders() {
        return orders.size();
    }

    double totalOrderValues(DishManager dishes) {
        double total = 0;

        for (Order o : orders)
            total += o.precoTotal(dishes);

        return total;
    }

    public void removeByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1) {
            orders.remove(idx);
            save();
        } else
            System.out.println("Pedido nao encontrado.");

    }

    public Order searchByCode(int code) {
        int idx = searchIdxByCode(code);

        if (idx != -1)
            return orders.get(idx);
        else
            return null;
    }

    public ArrayList<Order> searchByRestaurant(int restaurant_code) {
        ArrayList<Order> restaurant_orders = new ArrayList<>();

        for (Order o : orders) {
            if (o.restaurant == restaurant_code)
                restaurant_orders.add(o);
        }

        return restaurant_orders;
    }

    public ArrayList<Order> searchByClient(String email) {
        ArrayList<Order> restaurant_orders = new ArrayList<>();

        for (Order o : orders) {
            if (o.client_email.equals(email))
                restaurant_orders.add(o);
        }

        return restaurant_orders;
    }

    public int numOrdersByDish(int dish_code) {
        int total_orders = 0;

        for (Order o : orders) {
            int idx = o.codigos_produtos.indexOf(dish_code);
            if (idx >= 0)
                total_orders += o.quantidades.get(idx);
        }

        return total_orders;
    }

    public double totalValueByDish(Dish d) {
        int count = numOrdersByDish(d.codigo);
        double price = d.preco;
        return count * price;
    }

    public double totalValueByRestaurant(int restaurant_code, DishManager dishes) {
        ArrayList<Order> orders_by_restaurant = searchByRestaurant(restaurant_code);
        double total_val = 0;

        for (Order o : orders_by_restaurant)
            total_val += o.precoTotal(dishes);

        return total_val;
    }

    public double totalValueByClient(String user_email, DishManager dishes) {
        ArrayList<Order> orders_by_client = searchByClient(user_email);
        double total_val = 0;

        for (Order o : orders_by_client)
            total_val += o.precoTotal(dishes);

        return total_val;
    }

    public void removeByRestaurant(int codigo) {
        for (int i = 0; i < orders.size(); i++)
            if (orders.get(i).restaurant == codigo)
                orders.remove(i);

        save();
    }

    private int searchIdxByCode(int code) {
        for (int i = 0; i < orders.size(); i++)
            if (orders.get(i).codigo == code)
                return i;

        return -1;
    }

    private void save() {
        try {
            FileWriter f = new FileWriter("orders.csv");
            for (Order o : orders) {
                f.write(o.codigo + ";" + o.restaurant + ";" + o.client_email + ";");

                for (int codigo_produto : o.codigos_produtos)
                    f.write(codigo_produto + ",");

                f.write(";");

                for (int quantidade_produto : o.quantidades)
                    f.write(quantidade_produto + ",");

                f.write("\n");
            }

            f.close();
        } catch (IOException e) {
            System.out.println("Arquivo 'orders.csv' nao pode ser salvo.");
        }
    }

    private void load() {
        try {
            File f = new File("orders.csv");
            Scanner s = new Scanner(f);

            while (s.hasNextLine()) {
                String line = s.nextLine();
                String parts[] = line.split(";");

                int codigo = Integer.parseInt(parts[0]);
                int lanchonete = Integer.parseInt(parts[1]);
                String email = parts[2];
                String pratos_str[] = parts[3].split(",");
                String quantidades_str[] = parts[4].split(",");

                ArrayList<Integer> pratos = new ArrayList<>();
                ArrayList<Integer> quantidades = new ArrayList<>();

                for (int i = 0; i < pratos_str.length; i++) {
                    pratos.add(Integer.parseInt(pratos_str[i]));
                    quantidades.add(Integer.parseInt(quantidades_str[i]));
                }

                orders.add(new Order(codigo, lanchonete, email, pratos, quantidades));
            }

            s.close();

        } catch (IOException e) {
            System.out.println("Arquivo 'orders.csv' nao encontrado.");
        }
    }
}
