
public class RestaurantTotalValueComparable implements Comparable<RestaurantTotalValueComparable> {
    public Restaurant restaurant;
    private double total_profit;

    public RestaurantTotalValueComparable(Restaurant restaurant, double total_profit) {
        this.restaurant = restaurant;
        this.total_profit = total_profit;
    }

    @Override
    public int compareTo(RestaurantTotalValueComparable o) {
        double r_score = total_profit;
        double o_score = o.total_profit;

        if (r_score < o_score)
            return -1;
        else if (r_score == o_score)
            return 0;
        else
            return 1;
    }
}
