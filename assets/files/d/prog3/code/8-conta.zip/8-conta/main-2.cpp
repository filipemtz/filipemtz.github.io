
#include <iostream>
#include "conta.h"

using namespace std;

int main()
{
    Conta *c1 = new Conta();
    Conta *c2 = new Conta();

    c1->deposito(100);  // ok
    c2->deposito(-50);  // mensagem informando que o valor eh invalido

    cout << "Valor disponivel em c1: " << c1->disponivel() << endl;
    cout << "Valor disponivel em c2: " << c2->disponivel() << endl;    

    c1->saque(50);  // ok
    c2->saque(50);  // ok (existe limite de cheque especial)
    c2->saque(-20); // saque nao realizado porque valor eh invalido
    c2->saque(500); // saque nao realizado por falta de limite

    cout << "Valor disponivel em c1: " << c1->disponivel() << endl;
    cout << "Valor disponivel em c2: " << c2->disponivel() << endl;    

    return 0;
}