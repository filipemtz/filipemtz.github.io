
class Conta 
{
    const double LIMITE_INICIAL_PADRAO = 100;

    // private
    double saldo;
    double limite;

public:
    Conta();
    void deposito(double valor);
    double disponivel();
    void saque(double valor);
    void alterar_limite(double novo_limite);
};

