
#include <iostream>
#include "conta.h"

using namespace std;

Conta::Conta()
{
    saldo = 0;
    limite = LIMITE_INICIAL_PADRAO;
}

void Conta::deposito(double valor)
{
    if (valor < 0)
        cout << "Valor invalido para deposito:" << valor << ". Operacao nao realizado." << endl;
    else
        saldo += valor; 
}

double Conta::disponivel()
{
    return saldo + limite;
}

void Conta::saque(double valor)
{
    if (valor < 0)
        cout << "Valor invalido para saque:" << valor << ". Operacao nao realizado." << endl;
    else if (valor > disponivel())
        cout << "Usuario nao possui saldo suficiente para o saque. Operacao nao realizada." << endl;
    else 
        saldo -= valor;    
}

void Conta::alterar_limite(double novo_limite)
{
    if (novo_limite < 0)
        cout << "Valor invalido para limite:" << novo_limite << ". Operacao nao realizada." << endl;
    else
        limite = novo_limite; 
}