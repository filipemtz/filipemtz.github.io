package funcionarios;

public class Empreitada {
	String descricao;
	double valor, pagamento;
	
	public Empreitada(String descricao, double valor, double pagamento) {
		super();
		this.descricao = descricao;
		this.valor = valor;
		this.pagamento = pagamento;
	}
	
	@Override
	public String toString() {
		return "Empreitada [descricao=" + descricao + ", valor=" + valor + ", pagamento=" + pagamento + "]";
	}
}
