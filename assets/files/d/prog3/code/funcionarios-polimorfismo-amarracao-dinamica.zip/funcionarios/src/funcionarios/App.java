package funcionarios;

import java.util.ArrayList;

public class App {
	public static void main(String[] args) {
		ArrayList<Funcionario> funcionarios = 
				new ArrayList<>();
		
		funcionarios.add(new Funcionario("jose", 5));
		funcionarios.add(new Professor(
				"marcos", 5, "mestrado"));
		
		Empreiteiro e = new Empreiteiro(
				"lucas", 5);
		e.empreitadas.add(
			new Empreitada("Conserto de calha", 1000, 200));
		e.empreitadas.add(
				new Empreitada("Telhado", 500, 300));
		e.empreitadas.add(
				new Empreitada("Conserto de mesa", 150, 50));
		
		funcionarios.add(e);
		
		for (Funcionario f : funcionarios)
			System.out.println(f.getSalario());
	}
}
