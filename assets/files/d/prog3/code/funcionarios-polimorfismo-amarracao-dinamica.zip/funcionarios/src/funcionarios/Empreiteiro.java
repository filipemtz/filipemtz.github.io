package funcionarios;

import java.util.ArrayList;

public class Empreiteiro extends Funcionario {
	ArrayList<Empreitada> empreitadas;

	public Empreiteiro(
			String nome, double tempo_trabalho) {
		super(nome, tempo_trabalho);
		this.empreitadas = new ArrayList<>();
	}

	@Override
	public String toString() {
		return "Empreiteiro [empreitadas=" + empreitadas + ", nome=" + nome + ", tempo_trabalho=" + tempo_trabalho
				+ "]";
	}
	
	@Override
	double getSalario() {
		double base = super.getSalario();
		
		for (Empreitada e : empreitadas)
			base += e.pagamento;
		
		return base;
	}

}


