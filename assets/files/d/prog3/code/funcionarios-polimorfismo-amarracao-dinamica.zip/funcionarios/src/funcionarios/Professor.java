package funcionarios;

public class Professor extends Funcionario {
	String titulacao;

	public Professor(
			String nome, double tempo_trabalho,
			String titulacao) {
		super(nome, tempo_trabalho);
		this.titulacao = titulacao;
	}

	@Override
	public String toString() {
		return "Professor [titulacao=" + titulacao + ", nome=" + nome + ", tempo_trabalho=" + tempo_trabalho + "]";
	}
	
	@Override
	double getSalario() {
		double base = super.getSalario();
		
		if (titulacao.equalsIgnoreCase("bacharelado"))
			base += 1000;
		else if (titulacao.equalsIgnoreCase("mestrado"))
			base += 2000;
		else if (titulacao.equalsIgnoreCase("doutorado"))
			base += 4000;
		
		return base;
	}
}




