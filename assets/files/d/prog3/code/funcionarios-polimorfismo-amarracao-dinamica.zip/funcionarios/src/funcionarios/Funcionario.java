package funcionarios;

public class Funcionario {
	String nome;
	double tempo_trabalho;
	
	double getSalario() {
		return 1000 * tempo_trabalho;
	}
	
	public Funcionario(String nome, double tempo_trabalho) {
		super();
		this.nome = nome;
		this.tempo_trabalho = tempo_trabalho;
	}

	@Override
	public String toString() {
		return "Funcionario [nome=" + nome + ", tempo_trabalho=" + tempo_trabalho + "]";
	}
}
