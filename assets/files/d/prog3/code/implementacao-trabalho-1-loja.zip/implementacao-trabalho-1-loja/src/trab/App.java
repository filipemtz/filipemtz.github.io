package trab;

import java.util.Scanner;

public class App {
	static int menu() {
		System.out.println("\nMenu de Opcoes");
		System.out.println("1) cadastrarCliente");
		System.out.println("2) cadastrar Produto");
		System.out.println("3) cadastrar Nota");
		System.out.println("4) listar Clientes");
		System.out.println("5) listar Produtos");
		System.out.println("6) listar Notas");
		System.out.println("7) remover Cliente");
		System.out.println("8) remover Produto");
		System.out.println("9) remover Nota");
		System.out.println("10) adicionar Item Nota");
		System.out.println("11) exibir Nota Fiscal");
		System.out.println("12) exibir Relatorio");
		System.out.println("13) listar Itens Categoria");
		System.out.println("14) Atualizar Produtos");
		System.out.println("0) Sair");
		System.out.print("Digite sua opcao: ");
		Scanner s = new Scanner(System.in);
		return s.nextInt();
	}
	
	public static void main(String[] args) {
		Loja loja = new Loja();
		
		while (true) {
			int opcao = menu(); 
			
			if (opcao == 0)
				break;
			else if (opcao == 1)
				loja.cadastrarCliente();
			else if (opcao == 2)
				loja.cadastrarProduto();
			else if (opcao == 3)
				loja.cadastrarNota();
			else if (opcao == 4)
				loja.listarClientes();
			else if (opcao == 5)
				loja.listarProdutos();
			else if (opcao == 6)
				loja.listarNotas();
			else if (opcao == 7) 
				loja.removerCliente();
			else if (opcao == 8) 
				loja.removerProduto();
			else if (opcao == 9) 
				loja.removerNota();
			else if (opcao == 10)
				loja.adicionarItemNota();
			else if (opcao == 11)
				loja.exibirNotaFiscal();
			else if (opcao == 12)
				loja.exibirRelatorio();
			else if (opcao == 13)
				loja.listarItensCategoria();
			else if (opcao == 14)
				loja.AtualizarProduto();
			else
				System.out.println("Opcao invalida.");
		}
		
		System.out.println("Programa encerrado.");
	}
}
