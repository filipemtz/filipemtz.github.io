package trab;

import java.util.Calendar;

public class Util {
	static String today() {
		Calendar c = Calendar.getInstance();
		
		int dia = c.get(Calendar.DAY_OF_MONTH);
		int mes = c.get(Calendar.MONTH) + 1; // janeiro eh 0
		int ano = c.get(Calendar.YEAR);
		
		return dia + "/" + mes + "/" + ano; 
	}
}
