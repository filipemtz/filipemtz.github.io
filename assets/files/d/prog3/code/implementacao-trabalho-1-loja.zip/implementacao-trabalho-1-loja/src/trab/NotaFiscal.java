package trab;

import java.util.ArrayList;

public class NotaFiscal {
	int codigo;
	Cliente comprador;
	String data;
	String metodoPagamento;
	ArrayList<ItemCompra> itens;
	
	public NotaFiscal(int codigo, Cliente comprador, String metodoPagamento) {
		this.codigo = codigo;
		this.comprador = comprador;
		this.metodoPagamento = metodoPagamento;
		
		this.itens = new ArrayList<>();
		this.data = Util.today();
	}

	@Override
	public String toString() {
		return "NotaFiscal [codigo=" + codigo + ", comprador=" + comprador 
				+ ", data=" + data + ", metodoPagamento="
				+ metodoPagamento + ", itens=" + itens + "]";
	}
	
	void adicionarItem(ItemCompra item) {
		itens.add(item);
	}
	
	double custoTotal() {
		double total = 0;
		
		for (ItemCompra item : itens) 
			total += item.custoTotal();
		
		return total;
	}
}
