package trab;

public class Produto {
	int codigo;
	String nome;
	double preco;
	String categoria;
	double desconto;
	int estoque;
	
	public Produto(int codigo, String nome, double preco, String categoria, 
			double desconto, int estoque) {
		this.codigo = codigo;
		this.nome = nome;
		this.preco = preco;
		this.categoria = categoria;
		this.desconto = desconto;
		this.estoque = estoque;
	}

	public Produto(int codigo, String nome, double preco, int estoque) {
		this(codigo, nome, preco, "", 0, estoque);
	}

	@Override
	public String toString() {
		return "Produto [codigo=" + codigo + ", nome=" + nome 
				+ ", preco=" + preco + ", categoria=" + categoria
				+ ", desconto=" + desconto + ", estoque=" + estoque + "]";
	}
	
	double custo() {
		return preco - preco * desconto;
	}
	
	void atualizarEstoque(int qtd) {
		estoque = qtd;
	}
	
	void atualizarDesconto(double val) {
		desconto = val;
	}

	void atualizarPreco(double val) {
		preco = val;
	}
}
