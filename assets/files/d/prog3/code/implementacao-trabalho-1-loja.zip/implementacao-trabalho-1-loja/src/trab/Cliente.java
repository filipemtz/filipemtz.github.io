package trab;

public class Cliente {
	String cpf;
	String nome;
	String telefone;
	
	public Cliente(String cpf, String nome, String telefone) {
		this.cpf = cpf;
		this.nome = nome;
		this.telefone = telefone;
	}
	
	@Override
	public String toString() {
		return "Cliente [cpf=" + cpf + ", nome=" + nome + 
				", telefone=" + telefone + "]";
	}
}
