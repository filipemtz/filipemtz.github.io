package trab;

import java.util.ArrayList;
import java.util.Scanner;

public class Loja {
	private ArrayList<Produto> produtos;
	private ArrayList<Cliente> clientes;
	private ArrayList<NotaFiscal> notas;
	private Scanner s;
	
	public Loja() {
		produtos = new ArrayList<>();
		clientes = new ArrayList<>();
		notas = new ArrayList<>();
		s = new Scanner(System.in);
	}

	void cadastrarCliente() {
		System.out.print("Digite o seu cpf: ");
		String cpf = s.next();
		
		System.out.print("Digite o seu nome: ");
		s.nextLine(); // para capturar o enter
		String nome = s.nextLine();
		
		System.out.print("Digite o seu telefone: ");
		String telefone = s.nextLine();

		clientes.add(new Cliente(cpf, nome, telefone));
	}

	void cadastrarProduto(){
		System.out.print("Digite o codigo: ");
		int codigo = s.nextInt();
		
		System.out.print("Digite o nome: ");
		s.nextLine(); // para capturar o enter
		String nome = s.nextLine();
		
		System.out.print("Digite o preco: ");
		double preco = s.nextDouble();
		
		System.out.print("Digite o categoria: ");
		s.nextLine(); // para capturar o enter
		String categoria = s.nextLine();
		
		System.out.print("Digite o desconto: ");
		double desconto = s.nextDouble();
		
		System.out.print("Digite o estoque: ");
		int estoque = s.nextInt();
		
		produtos.add(new Produto(codigo, nome, preco, categoria, desconto, estoque));
	}
	
	void cadastrarNota(){
		Cliente c = null;

		while (true) {
			System.out.print("CPF: ");
			String cpf = s.next();

			c = buscarCliente(cpf);

			if (c == null)
				System.out.println("Usuario nao encontrado. Tente novamente.");
			else
				break;
		}

		System.out.print("Codigo: ");
		int codigo = s.nextInt();

		System.out.print("Meio de pagamento: ");
		String meio_pagamento = s.next();

		notas.add(new NotaFiscal(codigo, c, meio_pagamento));
	}
	
	void listarClientes(){
		for (Cliente c : clientes) {
			System.out.println(c);
		}
	}
	
	void listarProdutos(){
		for (Produto p : produtos) {
			System.out.println(p);
		}
	}
	
	void listarNotas(){
		for (NotaFiscal n : notas) {
			System.out.println(n);
		}
	}
	
	Cliente buscarCliente(String cpf){
		int idx = buscaClienteIndice(cpf);
		
		if (idx == -1) 
			return null;
		else
			return clientes.get(idx);
	}
	
	int buscaClienteIndice(String cpf) {
		for (int i = 0; i < clientes.size(); i++)
			if (clientes.get(i).cpf.equals(cpf))
				return i;
		return -1;
		
	}
	
	Produto buscarProduto(int codigo){
		for (Produto p : produtos)
			if (p.codigo == codigo)
				return p;
		return null;
	}
	
	NotaFiscal buscarNota(int codigo){
		for (NotaFiscal n : notas)
			if (n.codigo == codigo)
				return n;
		return null;
	}
	
	void removerCliente(){
		System.out.print("Cliente a ser removido: ");
		String cpf = s.next();
		Cliente c = buscarCliente(cpf);
		clientes.remove(c);
	}
	
	void removerProduto(){
		System.out.print("Produto a ser removido: ");
		int codigo = s.nextInt();
		Produto p = buscarProduto(codigo);
		produtos.remove(p);
	}
	
	void removerNota(){
		System.out.print("Nota a ser removida: ");
		int codigo = s.nextInt();
		NotaFiscal n = buscarNota(codigo);
		notas.remove(n);
	}
	
	void adicionarItemNota(){
		System.out.print("Codigo da Nota: ");
		int codigo_nota = s.nextInt();
		
		System.out.print("Codigo do Produto: ");
		int codigo_produto = s.nextInt();
		
		System.out.print("Quantidade: ");
		int quantidade = s.nextInt();
		
		NotaFiscal n = buscarNota(codigo_nota);
		Produto p = buscarProduto(codigo_produto);
		
		n.adicionarItem(new ItemCompra(p, quantidade, p.custo()));
		p.atualizarEstoque(p.estoque - quantidade);
	}

	void listarProdutosMaisVendidos() {
		int qtdVendas[] = new int[produtos.size()];
		
		for (int i = 0; i < produtos.size(); i++) {
			for (NotaFiscal n: notas) {
				for (ItemCompra item : n.itens)
					if (item.produto == produtos.get(i))
						qtdVendas[i] += item.quantidade;
			}
		}
	}
	
	void exibirRelatorio(){
		System.out.println("Numero de Usuarios: " + clientes.size());
		System.out.println("Numero de Produtos: " + produtos.size());
		System.out.println("Numero de Compras: " + notas.size());
		
		double total = 0;

		for (NotaFiscal n : notas) 
			total += n.custoTotal();
		
		System.out.println("Total de vendas: " + total);
		
		listarProdutosMaisVendidos();
	}
	
	void listarItensCategoria(){
		System.out.print("Categoria: ");
		//s.nextLine(); // para capturar o enter
		String categoria = s.nextLine();
		
		for (Produto p : produtos) 
			if (p.categoria.equals(categoria))
				System.out.println(p);
	}
	
	void exibirNotaFiscal(){
		System.out.println("Digite o codigo: ");
		int codigo = s.nextInt();

		NotaFiscal n = buscarNota(codigo);

		System.out.println("Nome\tQtd\tR$ Unit\tR$ Total"); 

		for (ItemCompra item : n.itens) {
			System.out.println(
				item.produto.nome + "\t" + 
				item.quantidade + "\t" + 
				item.custoUnidade + "\t" + 
				item.custoTotal()
			);
		}
		
		System.out.println("Total: " + n.custoTotal());
	}

	void AtualizarProduto() {
		System.out.println("Digite o codigo: ");
		int codigo = s.nextInt();
		System.out.println("Digite o nome: ");
		s.nextLine(); // para capturar o enter
		String nome = s.nextLine();
		System.out.println("Digite o preco: ");
		double preco = s.nextDouble();
		System.out.println("Digite o categoria: ");
		s.nextLine(); // para capturar o enter
		String categoria = s.nextLine();
		System.out.println("Digite o desconto: ");
		double desconto = s.nextDouble();
		System.out.println("Digite o estoque: ");
		int estoque = s.nextInt();

		// como objetos sao referencias, ao mudar o produto
		// retornado pelo metodo buscarProduto, seus valores 
		// tambem serao atualizados no ArrayList
		Produto p = buscarProduto(codigo);
		p.nome = nome;
		p.categoria = categoria;
		p.atualizarEstoque(estoque);
		p.atualizarDesconto(desconto);
		p.atualizarPreco(preco);
	}

}
