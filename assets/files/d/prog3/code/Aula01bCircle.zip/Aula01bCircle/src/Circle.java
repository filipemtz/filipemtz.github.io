
import java.lang.Math;

public class Circle {
    double radius;
    double cx;
    double cy;

    public double area() {
        return Math.PI * Math.pow(radius, 2);
    }

    public double perimeter() {
        return 2 * Math.PI * radius;
    }
}
