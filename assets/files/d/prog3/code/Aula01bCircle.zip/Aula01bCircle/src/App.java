
public class App {
    public static void main(String[] args) throws Exception {
        Rectangle r1 = new Rectangle(2, 3);

        r1.height = 5;
        r1.width = 10;

        System.out.println(r1.area());
        System.out.println("The perimeter of r1 is: " + r1.perimeter());

        Rectangle r2 = new Rectangle(2.5, 3.5);

        r2.height = 3;
        r2.width = 4;

        System.out.println("The area of r2 is: " + r2.area());
        System.out.println("The perimeter of r2 is: " + r2.perimeter());
    }
}
