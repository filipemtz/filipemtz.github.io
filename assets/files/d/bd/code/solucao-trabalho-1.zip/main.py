
from datetime import datetime
import sqlite3


def menu():
    print("1) cadastrar cliente")
    print("2) atualizar cliente")
    print("3) remover cliente")
    print("4) listar clientes")
    print("5) cadastrar produto")
    print("6) atualizar produto")
    print("7) remover produto")
    print("8) listar produtos")
    print("9) cadastrar compra")
    print("10) atualizar compra")
    print("11) remover compra")
    print("12) listar compras")
    print("13) exibir relatorio")
    print("14) exibir nota fiscal")
    print("15) listar produtos por categoria")
    print("16) adicionar item na compra")
    print("0) sair")
    return int(input("opcao: "))


def executa_sql(cmd):
    con = sqlite3.connect("loja.db")
    cur = con.cursor()
    cur.execute(cmd)
    con.commit()
    con.close()


def executa_select(cmd):
    con = sqlite3.connect("loja.db")
    cur = con.cursor()
    # O fetchall() recupera todos os resultados e armazena na memoria como
    # uma lista. IMPORTANTE: Quando o banco de dados for muito grande, nao eh
    # recomendavel fazer isso.
    linhas = cur.execute(cmd).fetchall()
    con.close()
    return linhas


def exibe_tabular(linha):
    for coluna in linha:
        if coluna is None:
            print(f"{'NULL':25}", end=" ")
        else:
            print(f"{coluna:25}", end=" ")
    print()


def cadastrar_cliente():
    cpf = input("Digite o cpf:")
    nome = input("Digite o nome:")
    email = input("Digite o email:")
    telefone = input("Digite o telefone:")
    endereco = input("Digite o endereco:")
    executa_sql(
        f"INSERT INTO cliente VALUES('{cpf}', '{nome}', '{email}', '{telefone}', '{endereco}')")


def atualizar_cliente():
    cpf = input("Digite o cpf:")
    nome = input("Digite o novo nome:")
    email = input("Digite o novo email:")
    telefone = input("Digite o novo telefone:")
    endereco = input("Digite o novo endereco:")
    executa_sql(
        f"UPDATE cliente SET nome='{nome}', email='{email}',"
        f"telefone='{telefone}', endereco='{endereco}' "
        f"WHERE cpf='{cpf}'")


def remover_cliente():
    cpf = input("Digite o cpf:")

    # recupera todas as compras do cliente
    compras_cliente = executa_select(
        f"SELECT * FROM compra WHERE cpfCliente='{cpf}'")

    # remove os itens de cada compra
    for compra in compras_cliente:
        codigo_compra = compra[0]
        executa_sql(
            f"DELETE FROM itemCompra WHERE codigoCompra='{codigo_compra}'")

    # remove as compras do cliente
    executa_sql(f"DELETE FROM compra WHERE cpfCliente='{cpf}'")

    # remove o cliente
    executa_sql(f"DELETE FROM cliente WHERE cpf='{cpf}'")


def listar_clientes():
    clientes = executa_select("SELECT * FROM cliente")
    for cliente in clientes:
        exibe_tabular(cliente)


def cadastrar_produto():
    nome = input("Digite o nome: ")
    categoria = input("Digite o categoria: ")
    preco = float(input("Digite o preco: "))
    qtd = int(input("Digite o qtd: "))
    desconto = float(input("Digite o desconto: "))
    executa_sql(
        f"INSERT INTO produto(nome, categoria, preco, qtd, desconto) "
        f" VALUES('{nome}', '{categoria}', '{preco}', '{qtd}', '{desconto}')")


def atualizar_produto():
    codigo_produto = int(input("Digite o codigo do produto: "))
    nome = input("Digite o nome: ")
    categoria = input("Digite o categoria: ")
    preco = float(input("Digite o preco: "))
    qtd = int(input("Digite o qtd: "))
    desconto = float(input("Digite o desconto: "))

    executa_sql(
        f"UPDATE produto SET nome='{nome}', categoria='{categoria}', preco='{preco}', "
        f" qtd='{qtd}', desconto='{desconto}' WHERE codigo='{codigo_produto}'")


def remover_produto():
    codigo_produto = int(input("Digite o codigo do produto: "))
    executa_sql(
        f"DELETE FROM produto WHERE codigo='{codigo_produto}'")


def listar_produtos():
    produtos = executa_select("SELECT * FROM produto")
    for produto in produtos:
        exibe_tabular(produto)


def cadastrar_compra():
    cpf = input("CPF: ")
    meio_pag = input("meio de pagamento: ")
    hoje = datetime.now().strftime("%Y-%m-%d")
    executa_sql(
        f"INSERT INTO compra(cpfCliente, data, meioPagamento) VALUES('{cpf}', '{hoje}', '{meio_pag}')")


def atualizar_compra():
    codigo_compra = int(input("Digite o codigo da compra: "))
    cpf = input("CPF do cliente: ")
    meio_pagamento = input("meio de pagamento: ")
    data = input("data: ")
    executa_sql(
        f"UPDATE compra SET cpfCliente='{cpf}', data='{data}', meioPagamento='{meio_pagamento}' "
        f" WHERE codigo='{codigo_compra}'")


def remover_compra():
    codigo_compra = int(input("Digite o codigo da compra: "))
    executa_sql(f"DELETE FROM itemCompra WHERE codigoCompra='{codigo_compra}'")
    executa_sql(f"DELETE FROM compra WHERE codigo='{codigo_compra}'")


def listar_compras():
    compras = executa_select("SELECT * FROM compra")
    for compra in compras:
        exibe_tabular(compra)


def exibir_relatorio():
    # Os indices [0][0] sao usados abaixo para selecionar a primeira linha
    # retornada pelo fetchall e depois a primeira coluna da tupla
    print("Qtd produtos:",
          executa_select("SELECT COUNT(*) FROM produto")[0][0])
    print("Qtd compras:",
          executa_select("SELECT COUNT(*) FROM compra")[0][0])
    print("Qtd usuarios:",
          executa_select("SELECT COUNT(*) FROM cliente")[0][0])
    print("Valor total em compras:",
          executa_select("SELECT SUM(valor) * qtd FROM itemCompra")[0][0])


def exibir_nota_fiscal():
    codigo_compra = int(input("Digite o codigo da compra: "))

    total_compra = 0

    itens_compra = executa_select(
        f"SELECT * FROM itemCompra WHERE codigoCompra='{codigo_compra}'")

    print(f"{'Produto':15} {'QTD':5} {'R$ Unit':7} {'R$ Total':7}")

    for item in itens_compra:
        codigoProduto = item[2]
        qtd = item[3]
        valor = item[4]
        valor_total_item = qtd * valor
        total_compra += valor_total_item

        # para obter o nome do produto
        produto = executa_select(
            f"SELECT * FROM produto WHERE codigo='{codigoProduto}'")

        # o primeiro indice [0] eh porque o executa_select usa o fetchall e,
        # neste caso, a funcao vai retornar uma lista com um elemento, o produto
        # que possui o codigo dado.
        nome_produto = produto[0][1]

        print(
            f"{nome_produto:15} {str(qtd):5} {str(valor):7} {str(valor_total_item):7}")

    print(f"Total da Compra: {total_compra}.")


def listar_produtos_por_categoria():
    categoria = input("Digite a categoria: ")
    produtos = executa_select(
        f"SELECT * FROM produto WHERE categoria='{categoria}'")
    for produto in produtos:
        exibe_tabular(produto)


def adicionar_item_na_compra():
    codigo_compra = int(input("Digite o codigo da compra: "))
    codigo_produto = int(input("Digite o codigo do produto: "))
    qtd_comprada = int(input("Digite a quantidade do adquirida: "))

    # recupera os dados do produto para calcularmos o valor atual com desconto
    produto = executa_select(
        f"SELECT * FROM produto WHERE codigo='{codigo_produto}'")

    # O executa_select retorna o resultado como uma lista. Como so existe 1
    # produto no resultado, podemos acessa-lo usando o indice 0.
    preco_atual = produto[0][3]
    qtd_estoque = produto[0][4]
    desconto = produto[0][5]
    preco_venda = preco_atual - preco_atual * desconto

    # insere o item na compra
    executa_sql(f"INSERT INTO itemCompra(codigoCompra, codigoProduto, qtd, valor) "
                f" VALUES('{codigo_compra}', '{codigo_produto}', '{qtd_comprada}', '{preco_venda}')")

    # atualiza o estoque do produto
    nova_qtd = qtd_estoque - qtd_comprada
    executa_sql(
        f"UPDATE produto SET qtd='{nova_qtd}' WHERE codigo='{codigo_produto}'")


def main():
    while True:
        opcao = menu()

        if opcao == 1:
            cadastrar_cliente()
        elif opcao == 2:
            atualizar_cliente()
        elif opcao == 3:
            remover_cliente()
        elif opcao == 4:
            listar_clientes()
        elif opcao == 5:
            cadastrar_produto()
        elif opcao == 6:
            atualizar_produto()
        elif opcao == 7:
            remover_produto()
        elif opcao == 8:
            listar_produtos()
        elif opcao == 9:
            cadastrar_compra()
        elif opcao == 10:
            atualizar_compra()
        elif opcao == 11:
            remover_compra()
        elif opcao == 12:
            listar_compras()
        elif opcao == 13:
            exibir_relatorio()
        elif opcao == 14:
            exibir_nota_fiscal()
        elif opcao == 15:
            listar_produtos_por_categoria()
        elif opcao == 16:
            adicionar_item_na_compra()
        elif opcao == 0:
            break
        else:
            print("opcao invalida.")


if __name__ == "__main__":
    main()
