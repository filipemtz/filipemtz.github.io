
import sqlite3

con = sqlite3.connect("loja.db")
cur = con.cursor()

cur.execute(
    "CREATE TABLE produto(codigo INTEGER PRIMARY KEY, nome VARCHAR(64),"
    "categoria VARCHAR(32), preco FLOAT, qtd INT,"
    "desconto FLOAT)")

cur.execute(
    "CREATE TABLE compra(codigo INTEGER PRIMARY KEY, cpfCliente VARCHAR(12),"
    "data DATE, meioPagamento VARCHAR(16));")

cur.execute(
    "CREATE TABLE cliente(cpf VARCHAR(12) PRIMARY KEY, nome VARCHAR(64),"
    "email VARCHAR(64), telefone VARCHAR(64), endereco VARCHAR(64))")

cur.execute(
    "CREATE TABLE itemCompra(codigo INTEGER PRIMARY KEY, codigoCompra INT,"
    "codigoProduto INT, qtd INT, valor FLOAT)")

con.commit()
con.close()
