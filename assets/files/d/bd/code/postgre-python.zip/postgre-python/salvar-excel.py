
import psycopg2 as pg
import openpyxl

con = pg.connect(host="localhost",
                 database="exemplo",
                 user="postgres",
                 password="123")

cur = con.cursor()

cur.execute("SELECT * FROM funcionario")
funcionarios = cur.fetchall()

my_wb = openpyxl.Workbook()
my_sheet = my_wb.active

# cabecalho
my_sheet.cell(row=1, column=1).value = "ID"
my_sheet.cell(row=1, column=2).value = "Nome"
my_sheet.cell(row=1, column=3).value = "Idade"
my_sheet.cell(row=1, column=4).value = "CPF"

for row_id in range(len(funcionarios)):
    for col_id in range(4):  # 4 colunas na tabela
        my_sheet.cell(row=row_id+2, column=col_id+1).value = \
            funcionarios[row_id][col_id]

my_wb.save("query_funcionarios.xlsx")
con.close()
