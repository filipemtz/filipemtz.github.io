
import psycopg2 as pg

con = pg.connect(host="localhost",
                 database="exemplo",
                 user="postgres",
                 password="123")

cur = con.cursor()

# #####################################
# ATENCAO À SINTAXE DIFERENTE
# #####################################
cur.execute("SELECT * FROM funcionario")
result = cur.fetchall()

for row in result:
    print(row)

con.close()
