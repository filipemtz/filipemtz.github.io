--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4
-- Dumped by pg_dump version 14.4

-- Started on 2022-07-19 14:10:01

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 210 (class 1259 OID 16410)
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    codigo integer NOT NULL,
    nome character varying(64) NOT NULL,
    CONSTRAINT codigo_positivo CHECK ((codigo > 0))
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 16395)
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    cpf character varying(11) NOT NULL,
    nome character varying(64) NOT NULL,
    idade integer DEFAULT 0 NOT NULL,
    salario double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- TOC entry 3314 (class 0 OID 16410)
-- Dependencies: 210
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departamento (codigo, nome) FROM stdin;
1	ENGENHARIA DE PRODUCAO
\.


--
-- TOC entry 3313 (class 0 OID 16395)
-- Dependencies: 209
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (cpf, nome, idade, salario) FROM stdin;
123	jose	65	7950
456	maria	32	4859
789	carlos	23	850
\.


--
-- TOC entry 3173 (class 2606 OID 16415)
-- Name: departamento departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_pkey PRIMARY KEY (codigo);


--
-- TOC entry 3171 (class 2606 OID 16401)
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (cpf);


-- Completed on 2022-07-19 14:10:02

--
-- PostgreSQL database dump complete
--

