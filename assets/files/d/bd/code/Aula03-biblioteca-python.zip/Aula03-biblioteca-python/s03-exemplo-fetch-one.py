
import sqlite3

con = sqlite3.connect("biblioteca.db")
cur = con.cursor()
linhas = cur.execute(f"SELECT * FROM usuario WHERE cpf='123';")

# Extrai a primeira linha retornada pelo select como uma tupla. Se a tabela
# pessoa possui cpf varchar(12) PRIMARY KEY, nome VARCHAR(64), idade INTEGER e
# telefone VARCHAR(20), o resultado do .fetchone() seria
# (123, 'jose', 78, '123123-123123'). Se não existir uma pessoa com o cpf dado,
# o resultado do .fethone() será None.
pessoa = linhas.fetchone()

if pessoa is None:
    print("Não existe um usuário com esse cpf.")
else:
    print("Dados da pessoa:", pessoa)

    # atributos podem ser acessados individualmente usando índices:
    print("cpf:", pessoa[0])
    print("nome:", pessoa[1])
    print("idade:", pessoa[2])
    print("telefone:", pessoa[3])

con.commit()
con.close()
