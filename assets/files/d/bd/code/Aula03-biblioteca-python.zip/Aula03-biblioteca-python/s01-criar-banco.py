import sqlite3

con = sqlite3.connect("biblioteca.db")
cur = con.cursor()

cur.execute(
    "CREATE TABLE livro(codigo INTEGER PRIMARY KEY, titulo VARCHAR(64), ano INTEGER, genero VARCHAR(64), quantidade INTEGER);")

cur.execute(
    "CREATE TABLE usuario(cpf varchar(12) PRIMARY KEY, nome VARCHAR(64), idade INTEGER, telefone VARCHAR(20));")

cur.execute(
    "CREATE TABLE emprestimo(livro integer, pessoa VARCHAR(12), inicio DATE, final DATE);")

con.commit()

print("Tabelas criadas: ")
result = cur.execute("SELECT * FROM sqlite_schema WHERE type='table';")
for table in result:
    print(table)

con.close()
