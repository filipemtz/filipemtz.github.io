
import sqlite3
import datetime


def menu():
    print("\n-- Menu de Opcoes --")
    print("1) Cadastrar usuario")
    print("2) Listar usuarios")
    print("3) Cadastrar livro")
    print("4) Listar livros")
    print("5) Cadastrar Emprestimo")
    print("6) Listar Emprestimos")
    print("7) Calcular Multa")
    print("8) Devolver livro")
    print("0) Sair")
    opcao = int(input("Selecione sua opcao: "))
    return opcao


def inserir_usuario():
    print("\n-- Cadastro de Usuario --")
    cpf = input("CPF: ")
    nome = input("nome: ")
    idade = int(input("idade: "))
    telefone = input("telefone: ")

    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    cur.execute(
        f"INSERT INTO usuario VALUES('{cpf}', '{nome}', '{idade}', '{telefone}')")
    con.commit()
    con.close()

    print("\n* Usuário cadastrado com sucesso.")


def listar_usuarios():
    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    linhas = cur.execute(f"SELECT * FROM usuario;")

    print("\n-- Usuários Cadastrados --")
    for linha in linhas:
        print(f"{linha[0]:12} {linha[1]:20} {str(linha[2]):6} {linha[3]:20}")

    con.close()


def inserir_livro():
    print("\n-- Cadastro de Livro --")

    titulo = input("Titulo: ")
    ano = int(input("Ano de lancamento: "))
    genero = input("Genero: ")
    quantidade = int(input("Número de exemplares: "))

    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    cur.execute(
        f"INSERT INTO livro(titulo, ano, genero, quantidade) VALUES('{titulo}', '{ano}', '{genero}', '{quantidade}');")
    con.commit()
    con.close()


def listar_livros():
    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    linhas = cur.execute(f"SELECT * FROM livro;")

    print("\n-- Livros Cadastrados --")
    for linha in linhas:
        print(
            f"{str(linha[0]):5} {linha[1]:20} {str(linha[2]):6} {linha[3]:20} {str(linha[4]):6}")

    con.close()


def inserir_emprestimo():
    print("\n-- Cadastro de Emprestimo --")
    cpf = input("CPF do usuario: ")
    livro = int(input("Codigo do livro: "))
    hoje = datetime.datetime.today().strftime('%Y-%m-%d')
    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    cur.execute(
        f"INSERT INTO emprestimo VALUES('{livro}', '{cpf}', '{hoje}', NULL);")
    con.commit()
    con.close()


def listar_emprestimos():
    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    linhas = cur.execute(f"SELECT * FROM emprestimo;")

    print("\n-- Empréstimos Cadastrados --")
    for linha in linhas:
        print(
            f"{str(linha[0]):4} {linha[1]:15} {str(linha[2]):20} {str(linha[3]):20}")

    con.close()


def calcular_multa():
    print("\n-- Calcular Multa --")
    cpf = input("CPF do usuario: ")
    livro = int(input("Codigo do livro: "))
    # retorna a data de hoje no formato ano-mes-dia

    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    linhas = cur.execute(
        f"SELECT * FROM emprestimo WHERE livro='{livro}' AND pessoa='{cpf}';")

    emprestimo = linhas.fetchone()
    print("linha de retorno:", emprestimo)

    if emprestimo is None:
        print("Nao existem emprestimos cadastrados para esse livro e pessoa.")
    else:
        hoje = datetime.datetime.today()
        inicio = datetime.datetime.strptime(emprestimo[2], "%Y-%m-%d")
        data_limite = inicio + datetime.timedelta(days=7)
        dias_atraso = (hoje - data_limite).days

        if dias_atraso > 0:
            multa = 1.5 * dias_atraso
            print(f"Dias de atraso: {dias_atraso}. Multa: {multa}.")
        else:
            print("Emprestimo no prazo.")

    con.commit()
    con.close()


def devolver_livro():
    print("\n-- Devolver Livro --")
    cpf = input("CPF do usuario: ")
    livro = int(input("Codigo do livro: "))
    # retorna a data de hoje no formato ano-mes-dia
    hoje = datetime.datetime.today().strftime('%Y-%m-%d')

    con = sqlite3.connect("biblioteca.db")
    cur = con.cursor()
    cur.execute(
        f"UPDATE emprestimo SET final='{hoje}' WHERE pessoa='{cpf}' AND livro='{livro}' AND final IS NULL;")
    con.commit()
    con.close()


def main():
    while True:
        opcao = menu()

        if opcao == 1:
            inserir_usuario()
        elif opcao == 2:
            listar_usuarios()
        elif opcao == 3:
            inserir_livro()
        elif opcao == 4:
            listar_livros()
        elif opcao == 5:
            inserir_emprestimo()
        elif opcao == 6:
            listar_emprestimos()
        elif opcao == 7:
            calcular_multa()
        elif opcao == 8:
            devolver_livro()
        elif opcao == 0:
            break
        else:
            print("Opcao invalida. Tente novamente.")

    print("Programa encerrado com sucesso.")


if __name__ == "__main__":
    main()
